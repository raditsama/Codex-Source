# Resource Stopping Checklist & Azure Portal Guide — CSSP10353907

## 1. Request Overview & Analysis

* **CSSP Request ID**: `CSSP10353907`
* **Service Request (SR) Number**: `REQ000008194637`
* **Application Name**: `A-000285` – `Enterprise Application Observability`
* **Project Name**: `MySuiteApps` – `MyMinutes – 5 December 2017 (MyMinutes Subscription)`
* **Decommissioning Type**: `Partial`
* **Requestor**: `amarsyafiq.azma@petronas.com` (Amar)
* **Manager / Approver**: `chewjian.shin@petronas.com`
* **Backup Retention**: `1M` (1 Month)
* **Data Retention / Disposal**: `Disposal` (0 days retention post-approval)
* **Reason / Justification**: `Not in Used`

---

## 2. User Confirmation Analysis
From [Confirmation from User.txt](file:///C:/Works/Decommission/CSSP10353907/Confirmation%20from%20User.txt):
> *"Hi Radit, Yes, please proceed to Decommission the VM. `mulesoft-honeypot_osdisk_1_1d3be5fb7baf4532beec33283a522d7d` and the associated NIC/Public IP can be deleted as well. Thank you. Best regards, Amar"*

---

## 3. Target Resource Inventory

| Resource Type | Resource Name | Resource Group | Subscription Name & ID | Action |
| :--- | :--- | :--- | :--- | :--- |
| **Virtual Machine** | `mulesoft-honeypot` | `rg-elk-sandpit` | `myminutes (prod)`<br>`28bc2e9f-6879-40cf-8cf4-40411860db14` | **Stop (Deallocate)** |
| **OS Disk** | `mulesoft-honeypot_osdisk_1_1d3be5fb7baf4532beec33283a522d7d` | `rg-elk-sandpit` | `myminutes (prod)`<br>`28bc2e9f-6879-40cf-8cf4-40411860db14` | **Backup Snapshot (1M Retention)** |
| **Network Interface (NIC)** | `mulesoft-honeypot*` (Attached NIC) | `rg-elk-sandpit` | `myminutes (prod)`<br>`28bc2e9f-6879-40cf-8cf4-40411860db14` | **Isolate / Check Public IP** |
| **Public IP Address** | Associated Public IP (if configured) | `rg-elk-sandpit` | `myminutes (prod)`<br>`28bc2e9f-6879-40cf-8cf4-40411860db14` | **Disassociate / Isolate** |
| **Azure Backup / RSV** | Recovery Services Vault (if protected) | `rg-elk-sandpit` / Shared RG | `myminutes (prod)`<br>`28bc2e9f-6879-40cf-8cf4-40411860db14` | **Stop Backup & Retain Data (1M)** |

---

## 4. Stopping Checklist

- [ ] **1. Backup / Snapshot Verification (1 Month Retention Policy)**
  - [ ] Check if `mulesoft-honeypot` is enrolled in Azure Backup (Recovery Services Vault).
  - [ ] If protected: Stop Backup and select **Retain Backup Data** (1M retention).
  - [ ] If not protected or manual backup required: Create a manual managed disk Snapshot with 1-month retention tag.
- [ ] **2. Stop & Deallocate Virtual Machine**
  - [ ] Navigate to VM `mulesoft-honeypot` in `rg-elk-sandpit`.
  - [ ] Trigger **Stop** from Azure Portal toolbar.
  - [ ] Verify status transitions to **`Stopped (deallocated)`**.
- [ ] **3. Network & Public IP Handling**
  - [ ] Check attached Network Interface (`NIC`) on `mulesoft-honeypot`.
  - [ ] Check if a **Public IP** address is attached. Disassociate or release if no longer receiving traffic.
- [ ] **4. Post-Stop State Verification**
  - [ ] Confirm VM compute billing has ceased (`Stopped (deallocated)`).
  - [ ] Document final state for RFC / Decommissioning execution phase.

---

## 5. Step-by-Step Azure Portal Instructions

### Step 1: Pre-requisite Backup / Snapshot (1 Month Retention)
According to the request metadata, **Backup Retention is 1 Month (1M)**.

#### Option A: If Protected via Recovery Services Vault (RSV)
1. Open the [Azure Portal](https://portal.azure.com).
2. Filter the subscription to **`myminutes (prod)`** (`28bc2e9f-6879-40cf-8cf4-40411860db14`).
3. Search for **Recovery Services vaults**.
4. Check the vault for `myminutes` or `rg-elk-sandpit`.
5. Under **Protected items** -> **Backup items**, locate **Azure Virtual Machine** -> `mulesoft-honeypot`.
6. Click `...` (More Options) -> **Stop backup**.
7. In the backup stop blade:
   - Select **Retain Backup Data** (do NOT choose Delete Backup Data).
   - Type the name of the backup item to confirm.
   - Click **Stop backup**.

#### Option B: Manual OS Disk Snapshot (If RSV is not configured)
1. In Azure Portal, search for **Disks** and select `mulesoft-honeypot_osdisk_1_1d3be5fb7baf4532beec33283a522d7d`.
2. On the top toolbar, click **+ Create snapshot**.
3. Fill in the snapshot details:
   - **Resource Group**: `rg-elk-sandpit`
   - **Name**: `snapshot-mulesoft-honeypot-osdisk-decomm`
   - **Snapshot type**: `Full`
   - **Storage type**: `Standard HDD` or `Standard SSD`
   - **Tags**: `Retention=1M`, `CSSP=CSSP10353907`, `DecommissionDate=2026-08`
4. Click **Review + create** -> **Create**.

---

### Step 2: Stop & Deallocate Virtual Machine (`mulesoft-honeypot`)
1. Go to **Virtual machines** in Azure Portal.
2. Ensure you are in subscription **`myminutes (prod)`**.
3. Select **`mulesoft-honeypot`** (located in Resource Group `rg-elk-sandpit`).
4. On the **Overview** page top toolbar, click **Stop**.
5. When prompted with the confirmation dialog, click **Yes / OK**.
6. Wait for the operation notification:
   - Status will change from *Running* -> *Stopping* -> **`Stopped (deallocated)`**.
7. **Verification**: When the VM is deallocated, compute charges stop, and Azure releases the hardware host allocation while keeping the disk and network configurations intact.

---

### Step 3: Check Associated Network Interface (NIC) & Public IP
1. In the **`mulesoft-honeypot`** VM blade, go to **Settings** -> **Networking** (or **Network settings**).
2. Note the attached Network Interface name.
3. Check the **Public IP** column:
   - If a Public IP is assigned: Click on the Public IP resource.
   - Under Overview, check if it is dynamic or static.
   - If required to disassociate before deletion, click **Disassociate** on the toolbar.

---

### Step 4: Verification & Readiness for RFC / Decommission Phase
1. Confirm that **`mulesoft-honeypot`** displays **Status: Stopped (deallocated)**.
2. Confirm the backup/snapshot is securely created with the 1-month retention tag.
3. The environment is now safely stopped and ready for subsequent decommissioning / deletion steps via IaC or manual RFC approval.
