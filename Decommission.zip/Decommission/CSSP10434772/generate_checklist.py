import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import csv
import zipfile
import xml.etree.ElementTree as ET
from excel_builder import ExcelBuilder

def main():
    builder = ExcelBuilder(r'c:\Works\Decommission\CSSP10434772\CSSP10434772_Decommissioning_Checklist.xlsx')
    
    # ----------------------------------------------------
    # SHEET 1: Summary & Ticket Info
    # ----------------------------------------------------
    s1_rows = []
    
    # Title
    s1_rows.append([
        {'val': 'PETRONAS DIGITAL — CLOUD DECOMMISSIONING TICKET SUMMARY', 'style': 1},
        None, None, None, None, None
    ])
    s1_rows.append([])
    
    # Section: Ticket Overview
    s1_rows.append([{'val': '1. TICKET & REQUEST METADATA', 'style': 2}, None, None, None, None, None])
    
    metadata = [
        ('CSSP Ticket ID', 'CSSP10434772', 'Decommissioning Type', 'Partial (Singapore Region only)'),
        ('Service Request (SR)', 'REQ000008246580', 'Backup Retention Policy', '2W (2 Weeks Mandatory Retention)'),
        ('Application ID & Name', 'A-000423 | Lab Information Management System - LIMS MLNG', 'Data Retention Policy', 'No Retention Policy Applied (0 days)'),
        ('Project Code & Name', '00915_213 | OCI MIGRATION - LIMS MLNG', 'Change Class for RFC', 'Standard (or No Impact for Non-Prod)'),
        ('Requestor Email', 'izdihar.roslan@petronas.com', 'Request Status', 'Approved by Requestor / Ready for Execution'),
        ('Manager / Approver', 'sazali.mokhtar@petronas.com', 'Target Scope', 'Singapore (SG) AWS & Azure Resources'),
        ('Decommission Justification', 'Cloud Repatriation - To decommission old resources in Singapore region due to completed migration in MY region', 'Protected Scope', 'Malaysia (MY) resources remain active (DO NOT DELETE)')
    ]
    
    for row in metadata:
        s1_rows.append([
            {'val': row[0], 'style': 12},
            {'val': row[1], 'style': 13},
            None,
            {'val': row[2], 'style': 12},
            {'val': row[3], 'style': 13},
            None
        ])
    s1_rows.append([])
    
    # Section: Contacts & Focal Points
    s1_rows.append([{'val': '2. KEY FOCAL POINTS & RESPONSIBLE TEAMS', 'style': 2}, None, None, None, None, None])
    s1_rows.append([
        {'val': 'Role / Team', 'style': 3},
        {'val': 'Focal Point Name', 'style': 3},
        {'val': 'Contact / Email', 'style': 3},
        {'val': 'Primary Responsibilities in Decommission', 'style': 3},
        None, None
    ])
    
    contacts = [
        ('Wintel Team', 'NorAzlisham / Wintel On-Call', '019-6667112', 'Unjoin domain, perform graceful VM shutdown, remove from SCCM'),
        ('Backup Team', 'Badri / Backup Admin', '017-2840094', 'Verify and execute pre-decommission backup/snapshot with 2W retention'),
        ('Cloud Operations (COC OPS)', 'Azwan / Cloud Ops', '016-9379010', 'Decommission AWS/Azure VMs, Storage, ALBs, CloudWatch via IaC/Console'),
        ('Cloud Database (COC DBA)', 'Alieff / DBA Ops', '017-6972830', 'Decommission AWS RDS databases (ptawsg-1lmlngdb01, ptawsg-5lmlngdb01)'),
        ('GOC Monitoring', 'GOC Duty Team', 'GOC Portal / Hotline', 'Remove/silence monitoring in SolarWinds, Dynatrace, E2E, CloudWatch'),
        ('Configuration / CMDB (CS)', 'Haniff Nazrin / CMDB Team', '03-38314045', 'Update CMDB Configuration Items status from Destroy to Disposed')
    ]
    
    for c in contacts:
        s1_rows.append([
            {'val': c[0], 'style': 6},
            {'val': c[1], 'style': 4},
            {'val': c[2], 'style': 5},
            {'val': c[3], 'style': 4},
            None, None
        ])
    s1_rows.append([])
    
    # Section: Execution Guidelines
    s1_rows.append([{'val': '3. CRITICAL OPERATIONAL NOTES & REMINDERS', 'style': 2}, None, None, None, None, None])
    guidelines = [
        "1. SCOPE ISOLATION: Only decommission Singapore (SG) resources. Never touch Malaysia (MY) resources.",
        "2. BACKUP MANDATE: A 2-week backup snapshot must be confirmed and tagged before triggering deletion.",
        "3. IAC PRIORITY: Perform deletion via Terraform IaC pipeline where available, fallback to Cloud Console.",
        "4. CMDB DISPOSAL: Ensure Task 6 is assigned to CMDB/CS team to reflect 'Disposed' in asset management.",
        "5. EVIDENCE RETENTION: Capture before/after screenshots of resource termination for RFC and SR closure."
    ]
    for g in guidelines:
        s1_rows.append([{'val': g, 'style': 4}, None, None, None, None, None])
        
    s1_widths = {1: 26, 2: 45, 3: 4, 4: 26, 5: 45, 6: 15}
    builder.add_sheet('Ticket Summary', s1_rows, s1_widths)
    
    
    # ----------------------------------------------------
    # SHEET 2: Decommission Checklist
    # ----------------------------------------------------
    s2_rows = []
    s2_rows.append([
        {'val': 'END-TO-END DECOMMISSIONING EXECUTION CHECKLIST — CSSP10434772', 'style': 1},
        None, None, None, None, None, None, None
    ])
    s2_rows.append([])
    
    s2_rows.append([
        {'val': 'Step #', 'style': 3},
        {'val': 'Phase / Category', 'style': 3},
        {'val': 'Activity & Detailed Procedure', 'style': 3},
        {'val': 'Action By (Team)', 'style': 3},
        {'val': 'Target System', 'style': 3},
        {'val': 'Status', 'style': 3},
        {'val': 'Completed Date/Time', 'style': 3},
        {'val': 'Remarks / Evidence Reference', 'style': 3}
    ])
    
    checklist_items = [
        # Phase 1
        ('1.1', 'Phase 1: CSSP Review', 'Review decommission request details, justification, and requestor/approver confirmation in CSSP portal', 'Cloud Ops / Lead', 'CSSP Portal', 'Completed', '19/08/2026', 'Approved by Izdihar Roslan & Sazali Mokhtar'),
        ('1.2', 'Phase 1: CSSP Review', 'Validate confirmed resource inventory (Confirm 16 AWS + 3 Azure SG resources, exclude all MY resources)', 'Cloud Ops / Lead', 'Inventory / Excel', 'Completed', '19/08/2026', 'Verified against confirmed attachments'),
        ('1.3', 'Phase 1: CSSP Review', 'Update review comments in CSSP portal and move ticket status to "Request Execution"', 'Cloud Ops', 'CSSP Portal', 'Pending', '', 'Triggers SR sync to MyGenie'),
        ('1.4', 'Phase 1: CSSP Review', 'Confirm generation/linking of MyGenie Service Request REQ000008246580', 'Cloud Ops', 'MyGenie Portal', 'Pending', '', 'SR REQ000008246580 linked'),

        # Phase 2
        ('2.1', 'Phase 2: Workplan Prep', 'Populate RFC Workplan template (Header, Reason for Change, Business Benefit, App A-000423, Project 00915_213)', 'Cloud Ops', 'Excel Workplan', 'Pending', '', 'Use ICT_RFC00225199 template'),
        ('2.2', 'Phase 2: Workplan Prep', 'Populate "Additional Info" tab with all confirmed AWS EC2, EBS, RDS, ALB and Azure Disks for Singapore', 'Cloud Ops', 'Excel Workplan', 'Pending', '', 'Include all SG Resource IDs & Tags'),
        ('2.3', 'Phase 2: Workplan Prep', 'Validate Pre-requisites, Testing Requirements (NA for decommission), and Implementation Verification tabs', 'Cloud Ops', 'Excel Workplan', 'Pending', '', 'Ensure rollback/fallback is defined'),
        ('2.4', 'Phase 2: Workplan Prep', 'Review and finalize RFC Workplan document for submission', 'Cloud Ops Lead', 'Excel Workplan', 'Pending', '', 'Ready for RFC attachment'),

        # Phase 3
        ('3.1', 'Phase 3: RFC Submission', 'Create new RFC in MyGenie Portal (Change Class: Standard / No Impact)', 'Cloud Ops', 'MyGenie ITSM', 'Pending', '', 'Specify LIMS MLNG Decommissioning'),
        ('3.2', 'Phase 3: RFC Submission', 'Relate Configuration Items (CIs) using %PTAWSG-1LMLNG% and %PTAZSG-IAC-DEV-LMLNG%', 'Cloud Ops', 'MyGenie ITSM', 'Pending', '', 'Attach all impacted SG CIs'),
        ('3.3', 'Phase 3: RFC Submission', 'Link Service Request REQ000008246580 and ticket CSSP10434772 in Related Items field', 'Cloud Ops', 'MyGenie ITSM', 'Pending', '', 'Ensures audit traceability'),
        ('3.4', 'Phase 3: RFC Submission', 'Upload finalized Workplan Excel document in Documents section', 'Cloud Ops', 'MyGenie ITSM', 'Pending', '', 'Mandatory RFC attachment'),
        ('3.5', 'Phase 3: RFC Submission', 'Create sequential RFC Implementation Tasks (Task 1: Wintel, Task 2: GOC, Task 3: Backup, Task 4: Cloud Ops/DBA, Task 5: Verification, Task 6: CMDB/CS)', 'Cloud Ops', 'MyGenie ITSM', 'Pending', '', 'Combine tasks per implementer'),
        ('3.6', 'Phase 3: RFC Submission', 'Transition RFC from Draft -> Request for Authorization -> Scheduled for Approval', 'Cloud Ops Lead / CAB', 'MyGenie ITSM', 'Pending', '', 'Wait for CAB / Schedule approval'),

        # Phase 4
        ('4.1', 'Phase 4: Pre-requisites', 'Task 3 (Backup): Take/verify final backup snapshot of EC2 VMs (PTAWSG-1LMLNGAP01, PTAWSG-1LMLNGAP02) and EBS volumes', 'Backup / Cloud Ops', 'AWS ap-southeast-1', 'Pending', '', 'Mandatory 2W retention'),
        ('4.2', 'Phase 4: Pre-requisites', 'Task 3 (Backup): Take/verify final snapshot of RDS Databases (ptawsg-1lmlngdb01, ptawsg-5lmlngdb01)', 'COC DBA / Backup', 'AWS ap-southeast-1', 'Pending', '', 'Mandatory 2W retention'),
        ('4.3', 'Phase 4: Pre-requisites', 'Tag backup snapshots with 2-Week Retention policy (Retention: 14 Days, ExpiryDate: <Date>)', 'Backup / Cloud Ops', 'AWS Backup / Snapshots', 'Pending', '', 'Enforce 2W retention policy'),
        ('4.4', 'Phase 4: Pre-requisites', 'Task 1 (Wintel): Unjoin VMs from Active Directory domain, perform graceful shutdown, remove from SCCM', 'Wintel Team', 'Windows OS / AD', 'Pending', '', 'VMs stopped in console'),
        ('4.5', 'Phase 4: Pre-requisites', 'Task 2 (GOC): Remove / silence monitoring alerts in SolarWinds, Dynatrace, E2E, and CloudWatch', 'GOC Team', 'Monitoring Tools', 'Pending', '', 'Prevent false decommission alarms'),

        # Phase 5
        ('5.1', 'Phase 5: Execution (AWS)', 'Task 4 (Cloud Ops): Delete Application Load Balancers (PTAWSG-1MLNG-APP-ALB, PTAWSG-1MLNG-INT-APP-ALB) and target groups', 'Cloud Ops', 'AWS ap-southeast-1', 'Pending', '', 'Account 947558275301'),
        ('5.2', 'Phase 5: Execution (AWS)', 'Task 4 (Cloud Ops): Terminate EC2 instances PTAWSG-1LMLNGAP01 (i-067cf8323e48354d5) and PTAWSG-1LMLNGAP02 (i-0ba2bdee7cf707f0e)', 'Cloud Ops', 'AWS ap-southeast-1', 'Pending', '', 'Account 947558275301'),
        ('5.3', 'Phase 5: Execution (AWS)', 'Task 4 (Cloud Ops): Delete all attached and unattached EBS volumes for SG VMs (vol-01d581ae1adbc3be2, vol-0800ae5e719836e69, etc.)', 'Cloud Ops', 'AWS ap-southeast-1', 'Pending', '', 'Account 947558275301'),
        ('5.4', 'Phase 5: Execution (AWS)', 'Task 4 (Cloud Ops): Delete confirmed EBS snapshots tagged for project 00915_213 in Singapore (older unneeded snapshots)', 'Cloud Ops', 'AWS ap-southeast-1', 'Pending', '', 'Account 947558275301'),
        ('5.5', 'Phase 5: Execution (AWS)', 'Task 4 (COC DBA): Delete RDS DB instance ptawsg-1lmlngdb01 in Account 947558275301 and ptawsg-5lmlngdb01 in Account 407331559142', 'COC DBA', 'AWS RDS ap-southeast-1', 'Pending', '', 'Final snapshot created per 2W policy'),
        ('5.6', 'Phase 5: Execution (AWS)', 'Task 4 (Cloud Ops): Delete CloudWatch Log Group /aws/lambda/cwsyn-limsmlng-5e3f746c-51e5-49ee-9858-db4d11ac45fe', 'Cloud Ops', 'AWS CloudWatch (575186022973)', 'Pending', '', 'Singapore canary log group'),
        ('5.7', 'Phase 5: Execution (Azure)', 'Task 4 (Cloud Ops): Delete Managed Disks PTSG-5LMLNGAP01_OsDisk, PTSG-5LMLNGAP01_DataDisk01, PTSG-5LMLNGAP01_DataDisk02 in PTAZSG-IAC-DEV-LMLNG-RG', 'Cloud Ops', 'Azure southeastasia', 'Pending', '', 'Subscription ptazsg-iac-dev'),
        ('5.8', 'Phase 5: Execution (Azure)', 'Task 4 (Cloud Ops): Clean up / delete empty resource group PTAZSG-IAC-DEV-LMLNG-RG if no other resources remain', 'Cloud Ops', 'Azure southeastasia', 'Pending', '', 'Confirm 0 resources remaining'),

        # Phase 6
        ('6.1', 'Phase 6: Verification & Close', 'Task 5 (Cloud Ops): Verify AWS Console and Azure Portal confirm 0 active Singapore resources and $0 ongoing cost for SG', 'Cloud Ops', 'AWS & Azure Consoles', 'Pending', '', 'Take post-deletion screenshots'),
        ('6.2', 'Phase 6: Verification & Close', 'Task 5 (App/Ops): Verify Malaysia (MY / ap-southeast-5) production workloads remain 100% healthy, accessible, and intact', 'Cloud Ops / App Team', 'MY Production App', 'Pending', '', 'Confirm zero service impact'),
        ('6.3', 'Phase 6: Verification & Close', 'Complete Task 4 and Task 5 in MyGenie with completion timestamps and attached evidence', 'Cloud Ops / DBA', 'MyGenie ITSM', 'Pending', '', 'Update task logs in portal'),
        ('6.4', 'Phase 6: Verification & Close', 'Task 6 (CMDB/CS): Update Configuration Item (CI) lifecycle status in CMDB to "Disposed"', 'CMDB / CS Team', 'MyGenie CMDB', 'Pending', '', 'Assets marked as Disposed'),
        ('6.5', 'Phase 6: Verification & Close', 'Close RFC in MyGenie with resolution status "Successful" and completion summary', 'Cloud Ops Lead', 'MyGenie ITSM', 'Pending', '', 'Change request closure'),
        ('6.6', 'Phase 6: Verification & Close', 'Close Service Request REQ000008246580 and update CSSP Portal CSSP10434772 to "Completed"', 'Cloud Ops', 'CSSP & MyGenie', 'Pending', '', 'Notify requestor Izdihar Roslan')
    ]
    
    for item in checklist_items:
        # Determine status style
        st = item[5]
        if st == 'Completed':
            st_style = 9
        elif st == 'In Progress':
            st_style = 8
        elif st == 'Pending' or st == 'Not Started':
            st_style = 7
        else:
            st_style = 5
            
        s2_rows.append([
            {'val': item[0], 'style': 5},
            {'val': item[1], 'style': 6},
            {'val': item[2], 'style': 4},
            {'val': item[3], 'style': 4},
            {'val': item[4], 'style': 5},
            {'val': item[5], 'style': st_style},
            {'val': item[6], 'style': 5},
            {'val': item[7], 'style': 4}
        ])
        
    s2_widths = {1: 8, 2: 24, 3: 50, 4: 18, 5: 22, 6: 14, 7: 18, 8: 35}
    builder.add_sheet('Decommission Checklist', s2_rows, s2_widths)
    
    
    # ----------------------------------------------------
    # SHEET 3: AWS SG Resources Checklist
    # ----------------------------------------------------
    s3_rows = []
    s3_rows.append([
        {'val': 'CONFIRMED AWS SINGAPORE RESOURCES (DECOMMISSION SCOPE) — PROJECT 00915_213', 'style': 1},
        None, None, None, None, None, None, None, None
    ])
    s3_rows.append([])
    s3_rows.append([
        {'val': 'Resource Category', 'style': 3},
        {'val': 'Resource Name / Hostname', 'style': 3},
        {'val': 'Resource ID / ARN', 'style': 3},
        {'val': 'AWS Account ID', 'style': 3},
        {'val': 'Region', 'style': 3},
        {'val': '2W Backup Status', 'style': 3},
        {'val': 'Deletion Status', 'style': 3},
        {'val': 'Action By', 'style': 3},
        {'val': 'Remarks / Notes', 'style': 3}
    ])
    
    aws_items = [
        ('EC2 Virtual Machine', 'PTAWSG-1LMLNGAP01', 'i-067cf8323e48354d5', '947558275301', 'ap-southeast-1', 'Pending Backup', 'Pending Deletion', 'Cloud Ops', 'Singapore App Server 01'),
        ('EC2 Virtual Machine', 'PTAWSG-1LMLNGAP02', 'i-0ba2bdee7cf707f0e', '947558275301', 'ap-southeast-1', 'Pending Backup', 'Pending Deletion', 'Cloud Ops', 'Singapore App Server 02'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP01 (Root)', 'vol-01d581ae1adbc3be2', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Attached to PTAWSG-1LMLNGAP01'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP01', 'vol-0408ac6322453fb7f', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Attached to PTAWSG-1LMLNGAP01'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP01', 'vol-0502dc3c6869cb3e2', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Attached to PTAWSG-1LMLNGAP01'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP01-data', 'vol-0375e24688993e624', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Data Volume'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02 (Root)', 'vol-0800ae5e719836e69', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Attached to PTAWSG-1LMLNGAP02'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02', 'vol-05eb3bc4818b9cfe1', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Attached to PTAWSG-1LMLNGAP02'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02', 'vol-0923dd3ae47290a47', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Attached to PTAWSG-1LMLNGAP02'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02-data', 'vol-0d40aa96604b75c3c', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Data Volume'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02-1B', 'vol-0312983d5a62496fd', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Backup / Secondary Volume'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02-1B', 'vol-0c5bf66f42768fbdc', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Backup / Secondary Volume'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02-1B', 'vol-0a7da946a800a689a', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Backup / Secondary Volume'),
        ('EBS Storage Volume', 'PTAWSG-1LMLNGAP02-1B', 'vol-0c0c996c2516f2e42', '947558275301', 'ap-southeast-1', 'Pending Snapshot', 'Pending Deletion', 'Cloud Ops', 'Backup / Secondary Volume'),
        ('RDS Database Instance', 'ptawsg-1lmlngdb01', 'arn:aws:rds:ap-southeast-1:947558275301:db:ptawsg-1lmlngdb01', '947558275301', 'ap-southeast-1', 'Pending Final Snapshot', 'Pending Deletion', 'COC DBA', 'Singapore Primary DB'),
        ('RDS Database Instance', 'ptawsg-5lmlngdb01', 'arn:aws:rds:ap-southeast-1:407331559142:db:ptawsg-5lmlngdb01', '407331559142', 'ap-southeast-1', 'Pending Final Snapshot', 'Pending Deletion', 'COC DBA', 'Singapore Secondary / Dev DB'),
        ('Application Load Balancer', 'PTAWSG-1MLNG-APP-ALB', 'arn:aws:elasticloadbalancing:ap-southeast-1:947558275301:loadbalancer/app/PTAWSG-1MLNG-APP-ALB/649e7c4ad99a753b', '947558275301', 'ap-southeast-1', 'N/A', 'Pending Deletion', 'Cloud Ops', 'External App ALB'),
        ('Application Load Balancer', 'PTAWSG-1MLNG-INT-APP-ALB', 'arn:aws:elasticloadbalancing:ap-southeast-1:947558275301:loadbalancer/app/PTAWSG-1MLNG-INT-APP-ALB/53e2f535a46b2d4f', '947558275301', 'ap-southeast-1', 'N/A', 'Pending Deletion', 'Cloud Ops', 'Internal App ALB'),
        ('CloudWatch Log Group', 'cwsyn-limsmlng', 'arn:aws:logs:ap-southeast-1:575186022973:log-group:/aws/lambda/cwsyn-limsmlng-5e3f746c-51e5-49ee-9858-db4d11ac45fe', '575186022973', 'ap-southeast-1', 'N/A', 'Pending Deletion', 'Cloud Ops', 'Synthetics Canary Log Group'),
        ('EBS Snapshots (Batch)', 'PTAWSG-1LMLNGAP01 Snapshots', '265 Snapshots under tag 00915_213', '947558275301', 'ap-southeast-1', 'Retain 2W Snapshot', 'Pending Deletion', 'Cloud Ops', 'Clean up unneeded historical snapshots'),
        ('EBS Snapshots (Batch)', 'PTAWSG-1LMLNGAP02 Snapshots', '29 Snapshots under tag 00915_213', '947558275301', 'ap-southeast-1', 'Retain 2W Snapshot', 'Pending Deletion', 'Cloud Ops', 'Clean up unneeded historical snapshots'),
        ('EBS Snapshots (Batch)', 'PTAWSG-1LMLNGAP01-DATA Snapshots', '124 Snapshots under tag 00915_213', '947558275301', 'ap-southeast-1', 'Retain 2W Snapshot', 'Pending Deletion', 'Cloud Ops', 'Clean up unneeded historical snapshots'),
        ('EBS Snapshots (Batch)', 'PTAWSG-1LMLNGAP02-1B Snapshots', '498 Snapshots under tag 00915_213', '947558275301', 'ap-southeast-1', 'Retain 2W Snapshot', 'Pending Deletion', 'Cloud Ops', 'Clean up unneeded historical snapshots')
    ]
    
    for r in aws_items:
        s3_rows.append([
            {'val': r[0], 'style': 6},
            {'val': r[1], 'style': 4},
            {'val': r[2], 'style': 4},
            {'val': r[3], 'style': 5},
            {'val': r[4], 'style': 5},
            {'val': r[5], 'style': 7},
            {'val': r[6], 'style': 7},
            {'val': r[7], 'style': 4},
            {'val': r[8], 'style': 4}
        ])
        
    s3_widths = {1: 22, 2: 28, 3: 45, 4: 16, 5: 15, 6: 18, 7: 18, 8: 15, 9: 30}
    builder.add_sheet('AWS SG Resources', s3_rows, s3_widths)
    
    
    # ----------------------------------------------------
    # SHEET 4: Azure SG Resources Checklist
    # ----------------------------------------------------
    s4_rows = []
    s4_rows.append([
        {'val': 'CONFIRMED AZURE SINGAPORE RESOURCES (DECOMMISSION SCOPE) — PROJECT 00915_213', 'style': 1},
        None, None, None, None, None, None, None
    ])
    s4_rows.append([])
    s4_rows.append([
        {'val': 'Resource Category', 'style': 3},
        {'val': 'Resource Name', 'style': 3},
        {'val': 'Resource Group', 'style': 3},
        {'val': 'Location', 'style': 3},
        {'val': 'Subscription / Environment', 'style': 3},
        {'val': 'Disk SKU / Size', 'style': 3},
        {'val': 'Deletion Status', 'style': 3},
        {'val': 'Action By', 'style': 3}
    ])
    
    az_items = [
        ('Managed OS Disk', 'PTSG-5LMLNGAP01_OsDisk', 'PTAZSG-IAC-DEV-LMLNG-RG', 'southeastasia', 'ptazsg-iac-dev environment (2be5068f-e0ac-4d57-aedc-96bc9798a265)', 'Standard HDD (S10)', 'Pending Deletion', 'Cloud Ops'),
        ('Managed Data Disk', 'PTSG-5LMLNGAP01_DataDisk01', 'PTAZSG-IAC-DEV-LMLNG-RG', 'southeastasia', 'ptazsg-iac-dev environment (2be5068f-e0ac-4d57-aedc-96bc9798a265)', 'Standard HDD (S10)', 'Pending Deletion', 'Cloud Ops'),
        ('Managed Data Disk', 'PTSG-5LMLNGAP01_DataDisk02', 'PTAZSG-IAC-DEV-LMLNG-RG', 'southeastasia', 'ptazsg-iac-dev environment (2be5068f-e0ac-4d57-aedc-96bc9798a265)', 'Standard HDD (S4)', 'Pending Deletion', 'Cloud Ops'),
        ('Resource Group Container', 'PTAZSG-IAC-DEV-LMLNG-RG', 'PTAZSG-IAC-DEV-LMLNG-RG', 'southeastasia', 'ptazsg-iac-dev environment (2be5068f-e0ac-4d57-aedc-96bc9798a265)', 'Resource Group', 'Pending Deletion (After Disks)', 'Cloud Ops')
    ]
    
    for r in az_items:
        s4_rows.append([
            {'val': r[0], 'style': 6},
            {'val': r[1], 'style': 4},
            {'val': r[2], 'style': 4},
            {'val': r[3], 'style': 5},
            {'val': r[4], 'style': 4},
            {'val': r[5], 'style': 5},
            {'val': r[6], 'style': 7},
            {'val': r[7], 'style': 4}
        ])
        
    s4_widths = {1: 22, 2: 28, 3: 28, 4: 16, 5: 38, 6: 18, 7: 18, 8: 15}
    builder.add_sheet('Azure SG Resources', s4_rows, s4_widths)
    
    
    # ----------------------------------------------------
    # SHEET 5: Excluded MY Resources (PROTECT)
    # ----------------------------------------------------
    s5_rows = []
    s5_rows.append([
        {'val': 'EXCLUDED MALAYSIA (MY) RESOURCES — PROTECTED ACTIVE PRODUCTION (DO NOT DELETE)', 'style': 1},
        None, None, None, None, None, None
    ])
    s5_rows.append([])
    s5_rows.append([
        {'val': 'CSP', 'style': 3},
        {'val': 'Account / Subscription', 'style': 3},
        {'val': 'Resource Name', 'style': 3},
        {'val': 'Meter Category / Type', 'style': 3},
        {'val': 'Monthly Cost (USD)', 'style': 3},
        {'val': 'Resource ID', 'style': 3},
        {'val': 'Protection Status', 'style': 3}
    ])
    
    # Load all MY resources from CSV
    with open(r'c:\Works\Decommission\CSSP10434772\cssp-decomm-resources-CSSP10434772.csv', mode='r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for r in reader:
            name = r['ResourceName']
            rg = r['ResourceGroup']
            resid = r['ResourceId']
            # Check if SG
            is_sg = ('sg' in name.lower() or 'sg' in rg.lower() or 'southeast-1' in resid.lower() or 'ptawsg' in name.lower() or 'ptazsg' in rg.lower() or 'ptsg' in name.lower())
            if not is_sg:
                s5_rows.append([
                    {'val': r['Csp'], 'style': 5},
                    {'val': r['SubscriptionName'], 'style': 5},
                    {'val': r['ResourceName'], 'style': 6},
                    {'val': f"{r['MeterCategory']} - {r['MeterSubCategory']}", 'style': 4},
                    {'val': r['MonthlyCostUsd'], 'style': 14},
                    {'val': r['ResourceId'], 'style': 4},
                    {'val': 'PROTECTED (DO NOT DELETE)', 'style': 10}
                ])
                
    s5_widths = {1: 10, 2: 18, 3: 26, 4: 32, 5: 18, 6: 45, 7: 25}
    builder.add_sheet('Excluded MY Resources (PROTECT)', s5_rows, s5_widths)
    
    # Save the workbook
    builder.save()
    print("Successfully generated C:\\Works\\Decommission\\CSSP10434772\\CSSP10434772_Decommissioning_Checklist.xlsx")

if __name__ == '__main__':
    main()
