import zipfile
import xml.etree.ElementTree as ET

path = r'C:\Works\Decommission\Procedure\ICT_RFC00225199 Workplan - Cloud Decommission 2026 - CSSP10478501.xlsx'

with zipfile.ZipFile(path) as z:
    sst = []
    if 'xl/sharedStrings.xml' in z.namelist():
        tree = ET.fromstring(z.read('xl/sharedStrings.xml'))
        for si in tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si'):
            t_elem = si.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
            if t_elem is not None and t_elem.text:
                sst.append(t_elem.text)
            else:
                t_parts = [r.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t').text for r in si.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}r') if r.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t') is not None and r.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t').text]
                sst.append(''.join(t_parts))
    
    wb_tree = ET.fromstring(z.read('xl/workbook.xml'))
    sheets = wb_tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheets/{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheet')
    
    for s in sheets:
        sheet_name = s.attrib['name']
        if sheet_name != 'Workplan':
            continue
        r_id = s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        rels_tree = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rel = [r for r in rels_tree if r.attrib['Id'] == r_id][0]
        sheet_file = 'xl/' + rel.attrib['Target']
        print(f'\n======================================================')
        print(f'=== SHEET: {sheet_name} ({sheet_file}) ===')
        print(f'======================================================')
        s_tree = ET.fromstring(z.read(sheet_file))
        rows = s_tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheetData/{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')
        for r in rows[:50]:
            row_items = []
            for c in r.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
                r_ref = c.attrib.get('r')
                v = c.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')
                val = v.text if v is not None else ''
                t = c.attrib.get('t')
                if t == 's' and val and int(val) < len(sst):
                    val = sst[int(val)]
                if val:
                    row_items.append(f'{r_ref}: {repr(val)}')
            if row_items:
                print(f'Row {r.attrib.get("r")}: ' + ' | '.join(row_items))
