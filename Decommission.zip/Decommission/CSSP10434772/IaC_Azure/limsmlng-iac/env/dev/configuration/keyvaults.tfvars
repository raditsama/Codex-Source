
keyvaults = {
  PTAZSG-5LMLNG-KV = {
    name               = "PTAZSG-5LMLNG-KV"
    resource_group_key = "PTAZSG-IAC-DEV-LMLNG-RG"
    sku_name           = "standard"
    creation_policies = {
      keyvault_level3_rw = {
        lz_key             = "launchpad"
        azuread_group_key  = "keyvault_level3_rw"
        secret_permissions = ["Set", "Get", "List", "Delete", "Purge"]
      }
      msi_level3 = {
        lz_key               = "launchpad"
        managed_identity_key = "level3"
        secret_permissions   = ["Set", "Get", "List", "Delete", "Purge"]
      }
    }
    soft_delete_enabled      = true
    purge_protection_enabled = true
  }
}

keyvault_access_policies = {
  PTAZSG-5LMLNG-KV = {
    PTAZ-DE-IS-COC-Operation-Contributor = {
      object_id          = "81bcfcfe-3ce2-416e-9ce5-e8be78723203"
      secret_permissions = ["Set", "Get", "List", "Delete", "Purge"]
    }
  }
}
