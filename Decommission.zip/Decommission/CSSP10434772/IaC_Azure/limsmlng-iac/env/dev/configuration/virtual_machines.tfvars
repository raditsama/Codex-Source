# ==============================================================================
# Virtual Machines Configuration
# ------------------------------------------------------------------------------
# Ticket Reference : CSSP10434772 / SR: REQ000008246580
# Project Code     : 00915_213 (OCI MIGRATION - LIMS MLNG)
# Application ID   : A-000423 (Lab Information Management System - LIMS MLNG)
# Change Reason    : Cloud Repatriation - Decommissioning of legacy Singapore (SG)
#                    resources following migration to Malaysia region.
#
# Target Decommission Resources:
#   - VM          : PTSG-5LMLNGAP01
#   - OS Disk     : PTSG-5LMLNGAP01_OsDisk (128 GB Standard SSD/HDD)
#   - Data Disk 01: PTSG-5LMLNGAP01_DataDisk01 (128 GB Standard SSD/HDD)
#   - Data Disk 02: PTSG-5LMLNGAP01_DataDisk02 (32 GB Standard SSD/HDD)
#   - NIC         : PTSG-5LMLNGAP01-nic01
#
# Note: Key Vault, Recovery Services Vault, and Resource Group remain preserved.
# ==============================================================================

# Empty map triggers Terraform to dismantle VM, attached OS disk, data disks, and NIC
virtual_machines = {}

# ------------------------------------------------------------------------------
# PREVIOUS CONFIGURATION (Decommissioned via CSSP10434772):
# ------------------------------------------------------------------------------
# virtual_machines = {
#   # Configuration to deploy LIMS MLNG App server
#   PTSG-5LMLNGAP01 = {
#     virtual_machine_settings = {
#       windows = {
#         name                            = "PTSG-5LMLNGAP01"
#         size                            = "Standard_D2as_v4"
#         admin_username                  = "manager"
#         disable_password_authentication = true
#         zone                            = "1"
#         custom_image_id                 = "/subscriptions/8a71ac81-04ed-4e9b-adea-c852951f4d69/resourceGroups/PTAZSG-CORE-VM-IMAGES-RG/providers/Microsoft.Compute/galleries/PTAZSG_3COC_VM_Images/images/PTAZSG-3COC-WS2019"
# 
#         # Value of the nic keys to attach the VM. The first one in the list is the default nic
#         network_interface_keys = ["PTSG-5LMLNGAP01-nic01"]
# 
#         os_disk = {
#           name                 = "PTSG-5LMLNGAP01_OsDisk"
#           caching              = "ReadWrite"
#           storage_account_type = "StandardSSD_LRS"
#           disk_size_gb         = "128"
#           zones                = [1]
#         }
#       }
#     }
# 
#     backup = {
#       vault_key  = "PTAZSG-IAC-DEV-LMLNG-RSV-ZRS"
#       policy_key = "PTAZSG-IAC-DEV-LMLNG-RSV-VMPolicy"
#       #lz_key = "" if in landing zone context, you can get the state from a remote LZ using this key
#     }
# 
#     # Data disk block
#     data_disks = {
#         vm_data_disk01 = {
#         name                 = "PTSG-5LMLNGAP01_DataDisk01"
#         storage_account_type = "StandardSSD_LRS"
#         create_option        = "Empty" # Only Empty is supported. More community contributions required to cover
#         disk_size_gb         = "128"
#         lun                  = 1
#         zones                = [1]
#         }
# 
#         vm_data_disk02 = {
#         name                 = "PTSG-5LMLNGAP01_DataDisk02"
#         storage_account_type = "StandardSSD_LRS"
#         create_option        = "Empty" # Only Empty is supported. More community contributions required to cover
#         disk_size_gb         = "32"
#         lun                  = 2
#         zones                = [1]
#         }
#     }
# 
#     # Define the number of networking cards to attach the virtual machine
#     networking_interfaces = {
#       PTSG-5LMLNGAP01-nic01 = {
#         # Value of the keys from networking.tfvars
#         lz_key                  = "networking_spoke_virtual_machines"
#         vnet_key                = "vm_region1"
#         subnet_key              = "PTAZSG-5SUBNET-APP"
#         name                    = "PTSG-5LMLNGAP01-nic01"
#         enable_ip_forwarding    = false
#         internal_dns_name_label = "PTSG-5LMLNGAP01-nic01"
#         # public_ip_address_key   = "sql_server_vm_pip"
# 
#         # configuration below need to be added if the nic is using dynamic IP
#         private_ip_address_allocation = "Static"
#         private_ip_address  = "172.25.168.14"
#         private_ip_address_version = "IPv4"
#       }
#     }
# 
#     resource_group_key                   = "PTAZSG-IAC-DEV-LMLNG-RG"
#     provision_vm_agent                   = true
#     boot_diagnostics_storage_account_key = "bootdiag_region1"
#     os_type = "windows"
# 
#     # the auto-generated ssh key in keyvault secret. Secret name being {VM name}-ssh-public and {VM name}-ssh-private
#     keyvault_key = "PTAZSG-5LMLNG-KV"
#   }
# }

