recovery_vaults = {
  PTAZSG-IAC-DEV-LMLNG-RSV-ZRS = {
    name               = "PTAZSG-IAC-DEV-LMLNG-RSV-ZRS"
    resource_group_key = "PTAZSG-IAC-DEV-LMLNG-RG"
    region = "region1"
    storage_mode_type = "ZoneRedundant"

    backup_policies = {
      vms = {
        PTAZSG-IAC-DEV-LMLNG-RSV-VMPolicy = {
          name      = "PTAZSG-IAC-DEV-LMLNG-RSV-VMPolicy"
          vault_key = "PTAZSG-IAC-DEV-LMLNG-RSV-ZRS"
          rg_key    = "PTAZSG-IAC-DEV-LMLNG-RG"
          timezone  = "Singapore Standard Time" #default = UTC
          instant_restore_retention_days = 1

          backup = {
            frequency = "Daily"
            time      = "18:00"
            #if not desired daily, can pick weekdays as below:
            #weekdays  = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
          }
          retention_daily = {
            count = 14
          }
          retention_monthly = {
            count    = 3
            weekdays = ["Friday"]
            weeks    = ["Last"]
          }

        /*
          retention_daily = {
            count = 7
          }
          retention_weekly = {
            count    = 4
            weekdays = ["Friday"]
          }
          retention_monthly = {
            count    = 12
            weekdays = ["Friday"]
            weeks    = ["Last"]
          }
          retention_yearly = {
            count    = 7
            weekdays = ["Friday"]
            weeks    = ["Last"]
            months   = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
          }
        */
        }
      }
    }
  }
}
