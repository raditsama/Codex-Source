#
# CAF Landing zone definition
#

landingzone = {
  backend_type        = "azurerm"
  global_settings_key = "shared_services"
  level               = "level3"
  key                 = "limsmlng"
  tfstates = {
    limsmlng_resources = {
      level   = "current"
      tfstate = "limsmlng_resources.tfstate"
    }
    networking_spoke_virtual_machines = {
      level   = "lower"
      tfstate = "networking_spoke_virtual_machines.tfstate"
    }
    shared_services = {
      level   = "lower"
      tfstate = "caf_shared_services.tfstate"
    }
  }
}

resource_groups = {
  PTAZSG-IAC-DEV-LMLNG-RG = {
    name   = "PTAZSG-IAC-DEV-LMLNG-RG"
    region = "region1" // region1 == southeastasia (refer to launchpad tfvars)
  }
}

#
# Inherited Tags
#

tags = {
  Project_Code           = "00915_213"
  CostCenter             = "004132-201"
  ApplicationId          = "LIMSMLNG"
  ApplicationName        = "Cloud Migration Program - LIMS MLNG"
  environment            = "Development"
  DataClassification     = "Confidential"
  SCAClassification      = "Standard"
  CSBIA_Confidentiality  = "Major"
  CSBIA_Integrity        = "Moderate"
  CSBIA_Availability     = "Major"
  CSBIA_ImpactScore      = "Major"
  IACRepo                = "https://dev.azure.com/petronasvsts/LIMS%20MLNG/_git/limsmlng-iac"
  ProductOwner           = "siowfui.chen@petronas.com"
  ProductSupport         = "hisham.sakor@petronas.com"
  BusinessOwner          = "francis_gobel@petronas.com"
  BusinessStream         = "Gas & New Energy"
  BusinessOPU_HCU        = "Malaysia LNG Sdn Bhd"
}
