data "aws_secretsmanager_secret" "secret_01" {
  arn = "arn:aws:secretsmanager:ap-southeast-1:111171751255:secret:PTAW-IAC-PROD-GasNewEnergy/RDS/manager-CH3pDr"
}

data "aws_secretsmanager_secret_version" "secret_01" {
  secret_id = data.aws_secretsmanager_secret.secret_01.id
}

module "rds_01" {
  #source                 = "aws.tfe.petronas.com/PTAW-IAC-NLZ/rds/aws"
  #version                = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-rds?ref=refs/tags/v4.1.2"

  identifier             = "ptawsg-1lpgbdb01"
  db_name                = "LIMSPGB"
  instance_class         = "db.r5.large"
  username               = "manager"
  password               = jsondecode(data.aws_secretsmanager_secret_version.secret_01.secret_string)["password"]
  port                   = "1523"
  engine                 = "oracle-se2"
  multi_az               = true
  engine_version         = "19.0.0.0.ru-2024-07.rur-2024-07.r1"
  license_model          = "license-included"
  allocated_storage      = 200
  max_allocated_storage  = 1000
  kms_key_id             = "arn:aws:kms:ap-southeast-1:111171751255:key/mrk-70f394c20a14457491ff0da1b4196451"
  vpc_security_group_ids = [module.sg_01.this_security_group_id]
  db_subnet_group_name   = "ptawsg-iac-prod-db-subnet-group"
  parameter_group_name   = "default.oracle-se2-19"
  option_group_name      = "" //"ptawsg-iac-prod-gasnewnergy-rds-oracle-se2-option-group"
  apply_immediately      = true
  # db_instance_role_associations = { "S3_INTEGRATION" : "arn:aws:iam::947558275301:role/PTAW_IAC_PROD_GasNewEnergy_ORACLE_MIGRATION_ROLE" }

  tags = merge(var.tags_pgb, 
  { "Name" = "ptawsg-1lpgbdb01" }, 
  { "Backup" = "Yes" },
  { "Project_Code" = "OCI-00026" },
  { "map-migrated" = "commS21KBIL4RR" })
}

# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# Ensure manual/final snapshot 'ptawsg-1lmlngdb01-final-decomm-2w' is taken prior to deletion
# ==============================================================================
/*
module "rds_02" {
  #source                 = "aws.tfe.petronas.com/PTAW-IAC-NLZ/rds/aws"
  #version                = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-rds?ref=refs/tags/v4.1.2"

  identifier             = "ptawsg-1lmlngdb01"
  db_name                = "MLNGLIMS"
  instance_class         = "db.r5.large"
  username               = "manager"
  password               = jsondecode(data.aws_secretsmanager_secret_version.secret_01.secret_string)["password"]
  port                   = "1523"
  engine                 = "oracle-se2"
  multi_az               = true
  engine_version         = "19.0.0.0.ru-2024-07.rur-2024-07.r1"
  license_model          = "license-included"
  allocated_storage      = 150
  kms_key_id             = "arn:aws:kms:ap-southeast-1:111171751255:key/mrk-70f394c20a14457491ff0da1b4196451"
  vpc_security_group_ids = [module.sg_02.this_security_group_id]
  db_subnet_group_name   = "ptawsg-iac-prod-db-subnet-group"
  parameter_group_name   = "default.oracle-se2-19"
  option_group_name      = "" //"ptawsg-iac-prod-gasnewnergy-rds-oracle-se2-option-group"
  apply_immediately      = true
  # db_instance_role_associations = { "S3_INTEGRATION" : "arn:aws:iam::947558275301:role/PTAW_IAC_PROD_GasNewEnergy_ORACLE_MIGRATION_ROLE" }

  tags = merge(var.tags_mlng, 
  { "Name" = "ptawsg-1lmlngdb01" }, 
  { "Backup" = "Yes" },
  { "Project_Code" = "OCI-00025" },
  { "map-migrated" = "commS21KBIL4RR" })
}
*/
