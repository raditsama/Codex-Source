module "sg_01" {
  #source      = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/securitygroup"
  #version     = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-ec2//modules/securitygroup?ref=refs/tags/v4.0.0"

  name        = "PTAWSG-IAC-PROD-LPCG-GASNEWENERGY-ORACLE-DB-SG"
  description = " LIMS PCG PROD GASNEWENERGY Oracle DB Security Group"
  vpc_id      = "vpc-0cd7c5a455db68964"
  ingress_with_cidr_blocks = [
    {
      from_port   = "1521"
      to_port     = "1521"
      protocol    = "tcp"
      description = "RDS access on 1521"
      cidr_blocks = "10.0.0.0/8"
    },
    {
      from_port   = "1521"
      to_port     = "1521"
      protocol    = "tcp"
      description = "RDS access on 1521 from Azure"
      cidr_blocks = "172.0.0.0/8"
    },
    {
      from_port   = "1523"
      to_port     = "1523"
      protocol    = "tcp"
      description = "RDS access on 1523"
      cidr_blocks = "10.0.0.0/8"
    },
    {
      from_port   = "1523"
      to_port     = "1523"
      protocol    = "tcp"
      description = "RDS access on 1523 from Azure"
      cidr_blocks = "172.0.0.0/8"
    }
  ]
  egress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic outbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  tags = merge(var.tags_pgb, { "Name" = "PTAWSG-IAC-PROD-LPCG-GASNEWENERGY-ORACLE-DB-SG" })
}

# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# ==============================================================================
/*
module "sg_02" {
  #source      = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/securitygroup"
  #version     = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-ec2//modules/securitygroup?ref=refs/tags/v4.0.0"

  name        = "PTAWSG-IAC-PROD-LMLNG-GASNEWENERGY-ORACLE-DB-SG"
  description = " LIMS MLNG PROD GASNEWENERGY Oracle DB Security Group"
  vpc_id      = "vpc-0cd7c5a455db68964"
  ingress_with_cidr_blocks = [
    {
      from_port   = "1521"
      to_port     = "1521"
      protocol    = "tcp"
      description = "RDS access on 1521"
      cidr_blocks = "10.0.0.0/8"
    },
    {
      from_port   = "1521"
      to_port     = "1521"
      protocol    = "tcp"
      description = "RDS access on 1521 from Azure"
      cidr_blocks = "172.0.0.0/8"
    },
    {
      from_port   = "1523"
      to_port     = "1523"
      protocol    = "tcp"
      description = "RDS access on 1523"
      cidr_blocks = "10.0.0.0/8"
    },
    {
      from_port   = "1523"
      to_port     = "1523"
      protocol    = "tcp"
      description = "RDS access on 1523 from Azure"
      cidr_blocks = "172.0.0.0/8"
    }
  ]
  egress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic outbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  tags = merge(var.tags_mlng, { "Name" = "PTAWSG-IAC-PROD-LMLNG-GASNEWENERGY-ORACLE-DB-SG" })
}
*/

#ALB Security Group
// --------------------------------------------------------------------------
module "sg_03" {
  #source      = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/securitygroup"
  #version     = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-ec2//modules/securitygroup?ref=refs/tags/v4.0.0"
  
  name        = "PTAWSG-IAC-PROD-LIMS-GASNEWENERGY-ALB-SG"
  description = "LIMS PROD GASNEWENERGY ALB Security Group"
  vpc_id      = "vpc-05b0c8ef6c5d526f1"
  ingress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic inbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  egress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic outbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  tags = { Name = "PTAWSG-IAC-PROD-LIMS-GASNEWENERGY-ALB-SG" }
}