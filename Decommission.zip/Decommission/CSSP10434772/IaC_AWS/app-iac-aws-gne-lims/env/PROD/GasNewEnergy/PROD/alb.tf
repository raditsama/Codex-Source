data "aws_subnet" "PROD-GasNewEnergy-Web-01-AZ1" {
  id = "subnet-0cce129cdcf48e00d"
}

data "aws_subnet" "PROD-GasNewEnergy-Web-01-AZ2" {
  id = "subnet-0e5ae41dc567077ab"
}

data "aws_subnet" "PROD-GasNewEnergy-Web-01-AZ3" {
  id = "subnet-0a9d459cd1b6d0dca"
}

data "aws_subnet" "PROD-GasNewEnergy-Web-Public-01-AZ1" {
  id = "subnet-01fe81a3408c56105"
}

data "aws_subnet" "PROD-GasNewEnergy-Web-Public-01-AZ2" {
  id = "subnet-0e26417c7863cc841"
}

data "aws_subnet" "PROD-GasNewEnergy-Web-Public-01-AZ3" {
  id = "subnet-0b9429c85d0124cfe"
}

/*
module "alb_01" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/alb"
  #version           = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/alb?ref=refs/tags/v4.1.1"

  alb_name          = "PTAWSG-1LPGB-APP-ALB"
  subnet_ids        = [data.aws_subnet.PROD-GasNewEnergy-Web-Public-01-AZ1.id, data.aws_subnet.PROD-GasNewEnergy-Web-Public-01-AZ2.id, data.aws_subnet.PROD-GasNewEnergy-Web-Public-01-AZ3.id]
  is_internal       = true
  lb_type           = "application"
  app_prefix        = "LPGB"
  sg_id             = [module.sg_03.this_security_group_id]
  idle_timeout      = "60"
  delete_protection = false # should turn this on for production!
  # tags = merge(var.tags_pgb, { "Name" = "PTAWSG-1LPGB-APP-ALB" })
}*/

# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# ==============================================================================
/*
module "alb_lims_mlng" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/alb"
  #version           = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/alb?ref=refs/tags/v4.1.1"

  alb_name          = "PTAWSG-1MLNG-APP-ALB"
  subnet_ids        = [data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ1.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ2.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ3.id]
  is_internal       = true
  lb_type           = "application"
  app_prefix        = "LMLNG"
  sg_id             = [module.sg_03.this_security_group_id]
  idle_timeout      = "60"
  delete_protection = false # should turn this on for production!
  tags = merge(var.tags_mlng, { "Name" = "PTAWSG-1MLNG-APP-ALB" })
}
*/

/*
module "alb_lims_int_mlng" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/alb"
  #version           = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/alb?ref=refs/tags/v4.1.1"

  alb_name          = "PTAWSG-1MLNG-INT-APP-ALB"
  subnet_ids        = [data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ1.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ2.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ3.id]
  is_internal       = true
  lb_type           = "application"
  app_prefix        = "LMLNG"
  sg_id             = [module.sg_03.this_security_group_id]
  idle_timeout      = "60"
  delete_protection = false # should turn this on for production!
  # tags = merge(var.tags_mlng, { "Name" = "PTAWSG-1MLNG-APP-ALB" })
}
*/


module "alb_03" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/alb"
  #version           = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/alb?ref=refs/tags/v4.1.1"

  alb_name          = "PTAWSG-1LPGB-INT-APP-ALB"
  subnet_ids        = [data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ1.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ2.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ3.id]
  is_internal       = true
  lb_type           = "application"
  app_prefix        = "LPGB"
  sg_id             = [module.sg_03.this_security_group_id]
  idle_timeout      = "60"
  delete_protection = false # should turn this on for production!
  tags = merge(var.tags_pgb, { "Name" = "PTAWSG-1LPGB-INT-APP-ALB" })
}

# module "alb_04" {
#   source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/alb"
#   version           = "~> 4.1.0"
#   alb_name          = "PTAWSG-1MLNG-INT-APP-ALB"
#   subnet_ids        = [data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ1.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ2.id, data.aws_subnet.PROD-GasNewEnergy-Web-01-AZ3.id]
#   is_internal       = true
#   lb_type           = "application"
#   app_prefix        = "LMLNG"
#   sg_id             = [module.sg_03.this_security_group_id]
#   idle_timeout      = "60"
#   delete_protection = false # should turn this on for production!
#   # tags = merge(var.tags_mlng, { "Name" = "PTAWSG-1MLNG-APP-ALB" })
# }

# ################################################################################
# # Listeners - listener submodule
# ################################################################################
# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# ==============================================================================
/*
module "lb_listener_lims_mlng_443" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/listener?ref=refs/tags/v4.1.1"

  load_balancer_arn = module.alb_lims_mlng.arn
  port              = 443
  protocol          = "HTTPS"
  certificate_arn   = "arn:aws:acm:ap-southeast-1:947558275301:certificate/ac64a1f8-591d-4cab-8fd6-f3a4b885acac"
  default_action = {
    type             = "forward"
    target_group_arn = module.lb_tg_lims_mlng_443.tg_arn
  }
}

module "lb_listener_lims_mlng_8443" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/listener?ref=refs/tags/v4.1.1"

  load_balancer_arn = module.alb_lims_mlng.arn
  port              = 8443
  protocol          = "HTTPS"
  certificate_arn   = "arn:aws:acm:ap-southeast-1:947558275301:certificate/ac64a1f8-591d-4cab-8fd6-f3a4b885acac"
  default_action = {
    type             = "forward"
    target_group_arn = module.lb_tg_lims_mlng_8443.tg_arn
  }
}
*/

/*
module "lb_listener_lims_mlng_int_443" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/listener?ref=refs/tags/v4.1.1"

  load_balancer_arn = module.alb_lims_int_mlng.arn
  port              = 443
  protocol          = "HTTPS"
  certificate_arn   = "arn:aws:acm:ap-southeast-1:947558275301:certificate/ac64a1f8-591d-4cab-8fd6-f3a4b885acac"
  default_action = {
    type             = "forward"
    target_group_arn = module.lb_tg_lims_mlng_443.tg_arn
  }
}
*/

/* 
module "lb_listener_lims_mlng_int_8443" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/listener?ref=refs/tags/v4.1.1"

  load_balancer_arn = module.alb_lims_int_mlng.arn
  port              = 8443
  protocol          = "HTTPS"
  certificate_arn   = "arn:aws:acm:ap-southeast-1:947558275301:certificate/ac64a1f8-591d-4cab-8fd6-f3a4b885acac"
  default_action = {
    type             = "forward"
    target_group_arn = module.lb_tg_lims_mlng_8443.tg_arn
  }
} */

module "lb_listener_03" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/listener?ref=refs/tags/v4.1.1"

  load_balancer_arn = module.alb_03.arn
  port              = 80
  protocol          = "HTTP"
  default_action = {
    type             = "forward"
    target_group_arn = module.lb_target_group_03.tg_arn
  }
}

# module "lb_listener_04" {
#   source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
#   version           = "~> 4.1"
#   load_balancer_arn = module.alb_04.arn
#   port              = 80
#   protocol          = "HTTP"
#   default_action = {
#     type             = "forward"
#     target_group_arn = module.lb_target_group_04.tg_arn
#   }
# }

module "lb_listener_05" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/listener?ref=refs/tags/v4.1.1"

  load_balancer_arn = module.alb_03.arn
  port              = 8443
  protocol          = "HTTPS"
  certificate_arn   = "arn:aws:acm:ap-southeast-1:947558275301:certificate/dbbb5e06-c52b-47c0-869b-bd33ef6b3e81"
  default_action = {
    type             = "forward"
    target_group_arn = module.lb_target_group_05.tg_arn
  }
}

# module "lb_listener_06" {
#   source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
#   version           = "~> 4.1"
#   load_balancer_arn = module.alb_03.arn
#   port              = 443
#   protocol          = "HTTPS"
#   certificate_arn   = "arn:aws:acm:ap-southeast-1:947558275301:certificate/dbbb5e06-c52b-47c0-869b-bd33ef6b3e81"
#   default_action = {
#     type             = "forward"
#     target_group_arn = module.lb_target_group_05.tg_arn
#   }
# }

# ################################################################################
# # Target Groups - target-group submodule
# ################################################################################
module "lb_target_group_03" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/target-group"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/target-group?ref=refs/tags/v4.1.1"

  name              = "PTAWSG-1LPGB-INT-APP-TG"
  port              = 80
  protocol          = "HTTP"
  target_type       = "ip"
  availability_zone = "all"
  vpc_id            = "vpc-05b0c8ef6c5d526f1"

  health_check = {
    interval            = 30
    protocol            = "HTTP"
    path                = "/"
    matcher             = "200-399"
    healthy_threshold   = 3
    unhealthy_threshold = 3
    timeout             = 10
  }

  tags = merge(var.tags_pgb, { "Name" = "PTAWSG-1LPGB-INT-APP-TG" })
}

# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# ==============================================================================
/*
module "lb_tg_lims_mlng_443" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/target-group"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/target-group?ref=refs/tags/v4.1.1"

  name              = "PTAWSG-1MLNG-INT-APP-TG"
  port              = 443
  protocol          = "HTTPS"
  target_type       = "ip"
  availability_zone = "all"
  vpc_id            = "vpc-05b0c8ef6c5d526f1"

  health_check = {
    interval            = 30
    protocol            = "HTTP"
    path                = "/mlnglims/logon.jsp"
    matcher             = "200-399"
    healthy_threshold   = 3
    unhealthy_threshold = 3
    timeout             = 10
  }

  tags = merge(var.tags_mlng, { "Name" = "PTAWSG-1MLNG-INT-APP-TG" })
}

module "lb_tg_lims_mlng_8443" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/target-group"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/target-group?ref=refs/tags/v4.1.1"

  name              = "PTAWSG-1MLNG-INT-8443-APP-TG"
  port              = 8443
  protocol          = "HTTP"
  target_type       = "ip"
  availability_zone = "all"
  vpc_id            = "vpc-05b0c8ef6c5d526f1"

  health_check = {
    interval            = 30
    protocol            = "HTTPS"
    path                = "/mlnglims/logon.jsp"
    matcher             = "200-399"
    healthy_threshold   = 3
    unhealthy_threshold = 3
    timeout             = 10
  }

  tags = merge(var.tags_mlng, { "Name" = "PTAWSG-1MLNG-INT-8443-APP-TG" })
}
*/

module "lb_target_group_05" {
  #source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/target-group"
  #version           = "~> 4.1"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/target-group?ref=refs/tags/v4.1.1"

  name              = "PTAWSG-1LPGB-INT-APP-HTTPS-TG"
  port              = 8443
  protocol          = "HTTPS"
  target_type       = "ip"
  availability_zone = "all"
  vpc_id            = "vpc-05b0c8ef6c5d526f1"

  health_check = {
    interval            = 30
    protocol            = "HTTPS"
    path                = "/limspgb/logon.jsp"
    matcher             = "200-399"
    healthy_threshold   = 3
    unhealthy_threshold = 3
    timeout             = 10
  }

  tags = merge(var.tags_pgb, { "Name" = "PTAWSG-1LPGB-INT-APP-HTTPS-TG" })
}

# module "lb_target_group_06" {
#   source            = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/target-group"
#   version           = "~> 4.1"
#   name              = "PTAWSG-1LPGB-INT-APP-HTTPS-TG"
#   port              = 443
#   protocol          = "HTTPS"
#   target_type       = "ip"
#   availability_zone = "all"
#   vpc_id            = "vpc-05b0c8ef6c5d526f1"

#   health_check = {
#     interval            = 30
#     protocol            = "HTTPS"
#     path                = "/limspgb/logon.jsp"
#     matcher             = "200-399"
#     healthy_threshold   = 3
#     unhealthy_threshold = 3
#     timeout             = 10
#   }
# }

