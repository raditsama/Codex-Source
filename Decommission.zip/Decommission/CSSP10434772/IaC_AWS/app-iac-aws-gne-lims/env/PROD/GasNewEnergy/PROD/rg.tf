#module "rg_01" {
  #source  = "aws.tfe.petronas.com/PTAW-IAC-NLZ/rg/aws"
  #version = "~> 4.0.0"

resource "aws_resourcegroups_group" "aws_rg01" {

  name        = "PTAWSG-IAC-PROD-GasNewEnergy-LIMS-PGB-RG"
  description = "Production Environment Infrastructure Deployment for LIMS PGB"
  tags        = var.tags_pgb

  resource_query {
    query = <<JSON
{
  "ResourceTypeFilters": [
    "AWS::AllSupported"
  ],
  "TagFilters": [
    {
        "Key": "ApplicationId",
        "Values": ["LIMSPGB"]
    }
  ]
}
JSON
  }
} 

#module "rg_02" {
  #source  = "aws.tfe.petronas.com/PTAW-IAC-NLZ/rg/aws"
  #version = "~> 4.0.0"

# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# ==============================================================================
/*
resource "aws_resourcegroups_group" "aws_rg02" {

  name        = "PTAWSG-IAC-PROD-GasNewEnergy-LIMS-MLNG-RG"
  description = "Production Environment Infrastructure Deployment for LIMS MLNG"
  tags        = var.tags_mlng

  resource_query {
    query = <<JSON
{
  "ResourceTypeFilters": [
    "AWS::AllSupported"
  ],
  "TagFilters": [
    {
        "Key": "ApplicationId",
        "Values": ["LIMSMLNG"]
    }
  ]
}
JSON
  }
} 
*/ 
