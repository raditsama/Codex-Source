# EC2 Security Group
// --------------------------------------------------------------------------
module "sg_01" {
  #source      = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/securitygroup"
  #version     = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-ec2//modules/securitygroup?ref=refs/tags/v4.0.0"

  name        = "PTAWSG-IAC-DEV-LIMS-PGB-GASNEWENERGY-EC2-SG"
  description = "NonPROD GasNewEnergy EC2 Security Group"
  vpc_id      = "vpc-0daa9e7d88b208008"
  ingress_with_cidr_blocks = [
    {
      from_port   = "3389"
      to_port     = "3389"
      protocol    = "tcp"
      description = "PETRONET RDP access"
      cidr_blocks = "10.0.0.0/8"
    },
    {
      from_port   = "3389"
      to_port     = "3389"
      protocol    = "tcp"
      description = "PETRONET RDP access"
      cidr_blocks = "172.0.0.0/8"
    }
  ]
  egress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic outbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  tags = { Name = "PTAWSG-IAC-DEV-LIMS-PGB-GASNEWENERGY-EC2-SG" }
}


#RDS Security Group
// --------------------------------------------------------------------------
module "sg_02" {
  #source      = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/securitygroup"
  #version     = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-ec2//modules/securitygroup?ref=refs/tags/v4.0.0"

  name        = "PTAWSG-IAC-DEV-LIMS-PGB-GASNEWENERGY-ORACLE-DB-SG"
  description = "NonPROD GasNewEnergy ORACLE DB Security Group"
  vpc_id      = "vpc-09d9de25f12593fa5"
  ingress_with_cidr_blocks = [
    {
      from_port   = "1521"
      to_port     = "1523"
      protocol    = "tcp"
      description = "Oracle Net Listener"
      cidr_blocks = "10.0.0.0/8"
    },
    {
      from_port   = "1521"
      to_port     = "1523"
      protocol    = "tcp"
      description = "Oracle Connection Manager"
      cidr_blocks = "172.0.0.0/8"
    },
    {
      from_port   = "1630"
      to_port     = "1630"
      protocol    = "tcp"
      description = "Oracle Connection Manager"
      cidr_blocks = "10.0.0.0/8"
    },
    {
      from_port   = "1630"
      to_port     = "1630"
      protocol    = "tcp"
      description = "Oracle Connection Manager"
      cidr_blocks = "172.0.0.0/8"
    }
  ]
  egress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic outbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  tags = { Name = "PTAWSG-IAC-DEV-RMS-GASNEWENERGY-ORACLE-DB-SG" }
}

#ALB Security Group
// --------------------------------------------------------------------------
module "sg_03" {
  #source      = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/securitygroup"
  #version     = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-ec2//modules/securitygroup?ref=refs/tags/v4.0.0"
  
  name        = "PTAWSG-IAC-DEV-LIMS-GASNEWENERGY-ALB-SG"
  description = "RMS NonPROD GasNewEnergy ALB Security Group"
  vpc_id      = "vpc-0c5ddd14447464e43"
  ingress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic inbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  egress_with_cidr_blocks = [
    {
      from_port   = 0
      to_port     = 0
      protocol    = -1
      description = "All traffic outbound rule"
      cidr_blocks = "0.0.0.0/0"
    }
  ]
  tags = { Name = "PTAWSG-IAC-DEV-LIMS-PGB-GASNEWENERGY-ALB-SG" }
}