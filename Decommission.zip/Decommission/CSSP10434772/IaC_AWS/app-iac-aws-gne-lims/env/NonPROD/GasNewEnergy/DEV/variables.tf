variable "default_tags" {default = {}}
variable "lims_mlng_tags" {default = {}}
variable "lims_pgb_tags" {default = {}}
