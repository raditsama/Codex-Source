module "rds_01" {
  #source                 = "aws.tfe.petronas.com/PTAW-IAC-NLZ/rds/aws"
  #version                = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-rds?ref=refs/tags/v4.1.2"

  identifier             = "ptawsg-5lpgbdb01"
  db_name                = "PGBDEV"
  instance_class         = "db.r5.large"
  username               = "manager"
  password               = jsondecode(data.aws_secretsmanager_secret_version.secret_01.secret_string)["password"]
  port                   = "1523"
  engine                 = "oracle-se2"
  engine_version         = "19.0.0.0.ru-2024-04.rur-2024-04.r1"
  license_model          = "license-included"
  allocated_storage      = 200
  kms_key_id             = "arn:aws:kms:ap-southeast-1:111171751255:key/mrk-e6a94f7f889849d6b8eff3a72c07a22c"
  vpc_security_group_ids = [module.sg_02.this_security_group_id]
  db_subnet_group_name   = "ptawsg-iac-nonprod-db-subnet-group"
  backup_window          = "16:00-18:00"
  parameter_group_name   = "default.oracle-se2-19"
  option_group_name      = "ptawsg-iac-nonprod-gasnewenergy-rds-oracle-se2-option-group"
  apply_immediately      = true
  #   timeouts = {
  #     create = "6h"
  #   }

  tags = merge(var.lims_pgb_tags, 
  { "Project_Code" = "OCI-00026" },
  { "Name" = "ptawsg-5lpgbdb01" },
  { "Backup" = "Major_NonProd_RDS"},
  { "map-migrated" = "commS21KBIL4RR" })
}

# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# Ensure manual/final snapshot 'ptawsg-5lmlngdb01-final-decomm-2w' is taken prior to deletion
# ==============================================================================
/*
module "rds_02" {
  #source                 = "aws.tfe.petronas.com/PTAW-IAC-NLZ/rds/aws"
  #version                = "~> 4.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-rds?ref=refs/tags/v4.1.2"
  
  identifier             = "ptawsg-5lmlngdb01"
  db_name                = "MLNGDEV"
  instance_class         = "db.r5.large"
  username               = "manager"
  password               = jsondecode(data.aws_secretsmanager_secret_version.secret_01.secret_string)["password"]
  port                   = "1523"
  engine                 = "oracle-se2"
  engine_version         = "19.0.0.0.ru-2024-04.rur-2024-04.r1"
  license_model          = "license-included"
  allocated_storage      = 100
  kms_key_id             = "arn:aws:kms:ap-southeast-1:111171751255:key/mrk-e6a94f7f889849d6b8eff3a72c07a22c"
  vpc_security_group_ids = [module.sg_02.this_security_group_id]
  db_subnet_group_name   = "ptawsg-iac-nonprod-db-subnet-group"
  backup_window          = "16:00-18:00"
  parameter_group_name   = "default.oracle-se2-19"
  option_group_name      = "ptawsg-iac-nonprod-gasnewenergy-rds-oracle-se2-option-group"
  apply_immediately      = true
  #   timeouts = {
  #     create = "6h"
  #   }

  tags = merge(var.lims_mlng_tags, 
  { "Project_Code" = "OCI-00025" },
  { "Name" = "ptawsg-5lmlngdb01" },
  { "Backup" = "Major_NonProd_RDS"},
  { "map-migrated" = "commS21KBIL4RR" })
} 
*/ 
