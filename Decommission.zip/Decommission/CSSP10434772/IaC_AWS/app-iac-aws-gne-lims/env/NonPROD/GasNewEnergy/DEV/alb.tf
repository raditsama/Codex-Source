/*

module "alb_01" {
  #source  = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/alb"
  #version = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/alb?ref=refs/tags/v4.1.1"

  alb_name                          = "PTAWSG-5LPGB-APP-ALB"
  subnet_ids                        = [data.aws_subnet.NonPROD-GasNewEnergy-Web-Public-01-AZ1.id,data.aws_subnet.NonPROD-GasNewEnergy-Web-Public-01-AZ2.id,data.aws_subnet.NonPROD-GasNewEnergy-Web-Public-01-AZ3.id]
  is_internal                       = true
  lb_type                           = "application"
  app_prefix                        = "LPGB"  
  sg_id                             = [module.sg_03.this_security_group_id]
  idle_timeout                      = "60"    
  delete_protection                 = false # should turn this on for production!
  tags = merge(var.lims_pgb_tags, { "Name" = "PTAWSG-5LPGB-APP-ALB"})
}

module "alb_02" {
  #source  = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/alb"
  #version = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/alb?ref=refs/tags/v4.1.1"

  alb_name                          = "PTAWSG-5LMLNG-APP-ALB"
  subnet_ids                        = [data.aws_subnet.NonPROD-GasNewEnergy-Web-Public-01-AZ1.id,data.aws_subnet.NonPROD-GasNewEnergy-Web-Public-01-AZ2.id,data.aws_subnet.NonPROD-GasNewEnergy-Web-Public-01-AZ3.id]
  is_internal                       = true
  lb_type                           = "application"
  app_prefix                        = "LMLNG"  
  sg_id                             = [module.sg_03.this_security_group_id]
  idle_timeout                      = "60"    
  delete_protection                 = false # should turn this on for production!
  tags = merge(var.lims_mlng_tags, { "Name" = "PTAWSG-5LMLNG-APP-ALB"})
}

################################################################################
# Listeners - listener submodule
################################################################################
module "lb_listener" {
  #source  = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/listener"
  #version = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/listener?ref=refs/tags/v4.1.1"

  load_balancer_arn = module.alb_01.arn
  port              = 80
  protocol          = "HTTP"
  default_action = {
    type             = "forward"
    target_group_arn = module.lb_target_group.tg_arn
  }
}

################################################################################
# Target Groups - target-group submodule
################################################################################
module "lb_target_group" {
  #source  = "aws.tfe.petronas.com/PTAW-IAC-NLZ/elb/aws//modules/target-group"
  #version = "~> 4.1.0"
  source = "git::git@ssh.dev.azure.com:v3/petronasvsts/PETRONAS_AWS_IAC_Module/terraform-aws-elb//modules/target-group?ref=refs/tags/v4.1.1"
  
  name              = "PTAWSG-IAC-NonProd-DEV-DownStream-OAS-APP-TG"
  port              = 80
  protocol          = "HTTP"
  target_type       = "ip"
  availability_zone = "all"
  vpc_id            = "vpc-0c5ddd14447464e43"

  health_check = {
    interval            = 30
    protocol            = "HTTP"
    path                = "/"
    matcher             = "200-399"
    healthy_threshold   = 3
    unhealthy_threshold = 3
    timeout             = 10
  }
}
*/