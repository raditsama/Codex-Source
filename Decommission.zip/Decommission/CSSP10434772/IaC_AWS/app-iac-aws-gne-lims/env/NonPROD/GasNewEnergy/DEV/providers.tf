terraform {
  required_version = ">= 1.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.44.0"
    }
  }
}

# default : singapore
provider "aws" {
  region = "ap-southeast-1"
  assume_role {
    role_arn = "arn:aws:iam::407331559142:role/PTAW_IAC_NonPROD_GasNewEnergy_PROVISION_ROLE"
  }

  default_tags {
    tags = var.default_tags
  }
}

provider "aws" {
  alias  = "nvirginia"
  region = "us-east-1"
  assume_role {
    role_arn = "arn:aws:iam::407331559142:role/PTAW_IAC_NonPROD_GasNewEnergy_PROVISION_ROLE"
  }

  # default_tags {
  #   tags = var.default_tags
  # }
}

