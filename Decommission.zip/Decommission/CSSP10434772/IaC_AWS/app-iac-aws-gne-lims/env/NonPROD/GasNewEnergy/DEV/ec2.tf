# # App Server 1
# // --------------------------------------------------------------------------
# module "instance_01" {
#   source    = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/instance"
#   version   = "~> 4.0"
#   depends_on = [module.sg_01]

#   name                   = "PTSG-5OASAP1"
#   ami                    = data.aws_ami.windows_server_2019.image_id # local.ami.WindowsServer2019.id
#   instance_type          = "m4.xlarge"
#   monitoring             = true
#   subnet_id              = data.aws_subnet.DownStream-Application-01-AZ1.id
#   iam_instance_profile   = "PTAW_IAC_NonPROD_DEV_DownStream_OAS_EC2_PROFILE"
#   user_data              = ""
#   key_name               = module.keypair_01.key_name
#   vpc_security_group_ids = [module.sg_01.this_security_group_id]
#   root_block_device = {
#     volume_size           = 128
#     volume_type           = "gp3"
#     delete_on_termination = true
#     encrypted             = true
#   }
#   ebs_block_device = {
#     volume_01 = {
#       name                  = "DataDisk01"
#       device_name           = "/dev/xvdb"
#       volume_size           = 128
#       volume_type           = "gp3"
#       delete_on_termination = true
#       encrypted             = true
#     }
#     volume_02 = {
#       name                  = "DataDisk02"
#       device_name           = "/dev/xvdc"
#       volume_size           = 30
#       volume_type           = "gp3"
#       delete_on_termination = true
#       encrypted             = true
#     }
#     volume_03 = {
#       name                  = "DataDisk03"
#       device_name           = "/dev/xvdd"
#       volume_size           = 64
#       volume_type           = "gp3"
#       delete_on_termination = true
#       encrypted             = true
#     }
#   }
#   ebs_kms_key   = "arn:aws:kms:ap-southeast-1:111171751255:key/mrk-a77a789eb7024815a393e04b423900f8"
#   ebs_optimized = true
#   tags = merge(var.default_tags, { "Name" = "PTSG-5OASAP1" })
# }
