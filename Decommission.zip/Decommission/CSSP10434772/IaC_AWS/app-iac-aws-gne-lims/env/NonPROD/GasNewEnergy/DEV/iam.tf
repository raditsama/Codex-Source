# module "iam_role01" {
#   source    = "aws.tfe.petronas.com/PTAW-IAC-NLZ/iam/aws//modules/role"
#   version   = "~> 4.0"
#   role_name    = "PTAW_IAC_NonPROD_DEV_DownStream_OAS_EC2_ROLE"
#   profile_name = "PTAW_IAC_NonPROD_DEV_DownStream_OAS_EC2_PROFILE" # Delete this line if Instance Profile is not needed

#   assume_policy = {
#     policy_file = file("policy/iam/role/role_01/assume-policy.json")
#   }

#   policy_arns = {
#     "AmazonEC2ReadOnlyAccess " = {
#       policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ReadOnlyAccess"
#     },
#     "AmazonSSMManagedInstanceCore " = {
#       policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
#     }
#   }

# #   inline_policy = {
# #     name        = "PTAW_IAC_PROD_PDnT_PIVOT_DA_LAMBDA_InlinePolicy"
# #     policy_file = file("policy/inline-policy.json")
# #   }

#   tags = {}
# }