# module "keypair_01" {
#   source    = "aws.tfe.petronas.com/PTAW-IAC-NLZ/ec2/aws//modules/key-pair"
#   version   = "~> 4.0"
#   key_name   = "PTAWSG-IAC-NonPROD-OAS-EC2-KeyPair"
#   public_key = jsondecode(data.aws_secretsmanager_secret_version.secret_02.secret_string)["public_key"]
#   tags       = { Name = "PTAWSG-IAC-NonPROD-OAS-EC2-KeyPair" }
# }