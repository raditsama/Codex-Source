terraform {
  backend "s3" {
    region  = "ap-southeast-1"
    encrypt = true
  }
}