data "aws_secretsmanager_secret" "secret_01" {
  arn = "arn:aws:secretsmanager:ap-southeast-1:111171751255:secret:PTAW-IAC-NonPROD-GasNewEnergy/RDS/manager-6DAe2p"
}

data "aws_secretsmanager_secret_version" "secret_01" {
  secret_id = data.aws_secretsmanager_secret.secret_01.id
}

data "aws_secretsmanager_secret" "secret_02" {
  arn = "arn:aws:secretsmanager:ap-southeast-1:111171751255:secret:PTAW-IAC-PROD-KeyManagement/KeyPairs/PTAWSG-IAC-PROD-KMS-EC2-KeyPair-g8HraF"
}

data "aws_secretsmanager_secret_version" "secret_02" {
  secret_id = data.aws_secretsmanager_secret.secret_02.id
}

//PTAWSG-5COC-WS2019-20230821
/*data "aws_ami" "windows_server_2019" {
  most_recent      = true

  filter {
    name   = "name"
    values = ["PTAWSG-5COC-WS2019-20230821"]
  }
}*/

data "aws_subnet" "NonPROD-GasNewEnergy-Web-01-AZ1" {
  id = "subnet-00b108559d047d6d1"
}

data "aws_subnet" "NonPROD-GasNewEnergy-Web-01-AZ2" {
  id = "subnet-0a14e51b7984f129c"
}

data "aws_subnet" "NonPROD-GasNewEnergy-Web-01-AZ3" {
  id = "subnet-09069abdf863098bb"
}

data "aws_subnet" "NonPROD-GasNewEnergy-Web-Public-01-AZ1" {
  id = "subnet-0b61a2a9db5c7a0ef"
}

data "aws_subnet" "NonPROD-GasNewEnergy-Web-Public-01-AZ2" {
  id = "subnet-0d1b8595f2625db11"
}

data "aws_subnet" "NonPROD-GasNewEnergy-Web-Public-01-AZ3" {
  id = "subnet-0bf3b7f4ba4c42885"
}