#module "rg" {
#  source  = "aws.tfe.petronas.com/PTAW-IAC-NLZ/rg/aws"
#  version = "~> 4.0"


resource "aws_resourcegroups_group" "aws_rg" {
  name        = "PTAWSG-IAC-NonPROD-DEV-GasNewEnergy-LIMS-PGB-RG"
  description = "Development Environment Infrastructure Deployment for LIMS-PGB"
  tags        = var.default_tags
  #tags        = merge(var.default_tags, {Project_Code = "02421_140"} , {map-migrated = "migS21KBIL4RR"})

  resource_query {
    query = <<JSON
{
  "ResourceTypeFilters": [
    "AWS::AllSupported"
  ],
  "TagFilters": [
    {
      "Key": "ApplicationId",
      "Values": [
        "LIMSPGB"
      ]
    }
  ]
}
JSON
  }
} 


# ==============================================================================
# DECOMMISSIONED - CSSP10434772 / REQ000008246580 (Project 00915_213 / OCI-00025)
# ==============================================================================
/*
resource "aws_resourcegroups_group" "aws_rg02" {
  name        = "PTAWSG-IAC-NonPROD-DEV-GasNewEnergy-LIMS-MLNG-RG"
  description = "Development Environment Infrastructure Deployment for LIMS-MLNG"
  tags        = var.lims_mlng_tags
  #tags        = merge(var.default_tags, {Project_Code = "02421_140"} , {map-migrated = "migS21KBIL4RR"})

  resource_query {
    query = <<JSON
{
  "ResourceTypeFilters": [
    "AWS::AllSupported"
  ],
  "TagFilters": [
    {
      "Key": "ApplicationId",
      "Values": [
        "LIMSMLNG"
      ]
    }
  ]
}
JSON
  }
} 
*/ 

