import zipfile
import xml.etree.ElementTree as ET
import html
import os

def escape_xml(s):
    if s is None:
        return ""
    return html.escape(str(s))

class ExcelBuilder:
    def __init__(self, filename):
        self.filename = filename
        self.sheets = []
        self.styles = []
        
    def add_sheet(self, name, rows, col_widths=None):
        self.sheets.append({
            'name': name,
            'rows': rows, # list of list of dicts: {'val': ..., 'style': ..., 'type': 'str'|'num'|'formula'}
            'col_widths': col_widths or {}
        })

    def col_to_letter(self, col_idx):
        result = ""
        while col_idx > 0:
            col_idx, remainder = divmod(col_idx - 1, 26)
            result = chr(65 + remainder) + result
        return result

    def build_styles_xml(self):
        # We will define fonts, fills, borders, cellXfs
        # Styles mapping:
        # 0: Default normal
        # 1: Title banner (Calibri 14 Bold, Dark Blue fill, White text)
        # 2: Section Header (Calibri 11 Bold, Medium Blue fill, White text)
        # 3: Table Header (Calibri 11 Bold, Slate Blue fill, White text, Center)
        # 4: Data Row Normal (Calibri 10 Regular, Thin border, Left)
        # 5: Data Row Center (Calibri 10 Regular, Thin border, Center)
        # 6: Data Row Bold (Calibri 10 Bold, Thin border, Left)
        # 7: Status Pending (Calibri 10 Bold, Yellow fill, Center, Dark Yellow text)
        # 8: Status In Progress (Calibri 10 Bold, Light Blue fill, Center)
        # 9: Status Completed (Calibri 10 Bold, Light Green fill, Center, Dark Green text)
        # 10: Status Protected (Calibri 10 Bold, Light Red/Pink fill, Center, Dark Red text)
        # 11: Phase Header (Calibri 11 Bold, Light Gray fill, Left)
        # 12: Key-Value Label (Calibri 10 Bold, Pale Blue fill, Left)
        # 13: Key-Value Value (Calibri 10 Regular, White fill, Left)
        # 14: Data Row Right (Calibri 10 Regular, Thin border, Right)

        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="6">
    <font><name val="Calibri"/><sz val="10"/><color rgb="FF000000"/></font>
    <font><name val="Calibri"/><sz val="14"/><b/><color rgb="FFFFFFFF"/></font>
    <font><name val="Calibri"/><sz val="11"/><b/><color rgb="FFFFFFFF"/></font>
    <font><name val="Calibri"/><sz val="10"/><b/><color rgb="FF000000"/></font>
    <font><name val="Calibri"/><sz val="10"/><b/><color rgb="FF856404"/></font>
    <font><name val="Calibri"/><sz val="10"/><b/><color rgb="FF155724"/></font>
    <font><name val="Calibri"/><sz val="10"/><b/><color rgb="FF721C24"/></font>
  </fonts>
  <fills count="10">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF1F4E79"/></patternFill></fill> <!-- 2: Dark Blue Title -->
    <fill><patternFill patternType="solid"><fgColor rgb="FF2F5597"/></patternFill></fill> <!-- 3: Medium Blue Section -->
    <fill><patternFill patternType="solid"><fgColor rgb="FF41719C"/></patternFill></fill> <!-- 4: Table Header -->
    <fill><patternFill patternType="solid"><fgColor rgb="FFFFF3CD"/></patternFill></fill> <!-- 5: Yellow Pending -->
    <fill><patternFill patternType="solid"><fgColor rgb="FFCCE5FF"/></patternFill></fill> <!-- 6: Blue In Progress -->
    <fill><patternFill patternType="solid"><fgColor rgb="FFD4EDDA"/></patternFill></fill> <!-- 7: Green Completed -->
    <fill><patternFill patternType="solid"><fgColor rgb="FFF8D7DA"/></patternFill></fill> <!-- 8: Red Protected -->
    <fill><patternFill patternType="solid"><fgColor rgb="FFEAECEE"/></patternFill></fill> <!-- 9: Light Gray Phase -->
    <fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill> <!-- 10: Pale Blue Label -->
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border>
      <left style="thin"><color rgb="FFD9D9D9"/></left>
      <right style="thin"><color rgb="FFD9D9D9"/></right>
      <top style="thin"><color rgb="FFD9D9D9"/></top>
      <bottom style="thin"><color rgb="FFD9D9D9"/></bottom>
    </border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="15">
    <!-- 0: Default -->
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <!-- 1: Title Banner -->
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <!-- 2: Section Header -->
    <xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <!-- 3: Table Header -->
    <xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <!-- 4: Data Row Normal -->
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
    <!-- 5: Data Row Center -->
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <!-- 6: Data Row Bold -->
    <xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <!-- 7: Status Pending -->
    <xf numFmtId="0" fontId="4" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <!-- 8: Status In Progress -->
    <xf numFmtId="0" fontId="3" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <!-- 9: Status Completed -->
    <xf numFmtId="0" fontId="5" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <!-- 10: Status Protected -->
    <xf numFmtId="0" fontId="6" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <!-- 11: Phase Header -->
    <xf numFmtId="0" fontId="3" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <!-- 12: Key-Value Label -->
    <xf numFmtId="0" fontId="3" fillId="10" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <!-- 13: Key-Value Value -->
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <!-- 14: Data Row Right -->
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
  </cellXfs>
</styleSheet>"""

    def build_worksheet_xml(self, sheet):
        rows = sheet['rows']
        col_widths = sheet['col_widths']
        
        xml_parts = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        ]
        
        if col_widths:
            xml_parts.append('<cols>')
            for col_idx, width in sorted(col_widths.items()):
                xml_parts.append(f'<col min="{col_idx}" max="{col_idx}" width="{width}" customWidth="1"/>')
            xml_parts.append('</cols>')
            
        xml_parts.append('<sheetData>')
        for r_idx, row in enumerate(rows, start=1):
            if not row:
                xml_parts.append(f'<row r="{r_idx}"/>')
                continue
            xml_parts.append(f'<row r="{r_idx}">')
            for c_idx, cell in enumerate(row, start=1):
                if cell is None:
                    continue
                cell_ref = f"{self.col_to_letter(c_idx)}{r_idx}"
                val = cell.get('val', '')
                style = cell.get('style', 0)
                cell_type = cell.get('type', 'str')
                
                style_attr = f' s="{style}"' if style else ''
                
                if cell_type == 'formula':
                    xml_parts.append(f'<c r="{cell_ref}"{style_attr}><f>{escape_xml(val)}</f></c>')
                elif cell_type == 'num':
                    xml_parts.append(f'<c r="{cell_ref}"{style_attr}><v>{val}</v></c>')
                else:
                    xml_parts.append(f'<c r="{cell_ref}"{style_attr} t="inlineStr"><is><t>{escape_xml(val)}</t></is></c>')
            xml_parts.append('</row>')
        xml_parts.append('</sheetData>')
        xml_parts.append('</worksheet>')
        return ''.join(xml_parts)

    def save(self):
        content_types = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
            '<Default Extension="xml" ContentType="application/xml"/>',
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        ]
        
        wb_rels = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
            '<Relationship Id="rId_styles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        ]
        
        workbook_xml = [
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">',
            '<sheets>'
        ]
        
        for idx, sheet in enumerate(self.sheets, start=1):
            part_name = f"/xl/worksheets/sheet{idx}.xml"
            rel_id = f"rId{idx}"
            content_types.append(f'<Override PartName="{part_name}" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
            wb_rels.append(f'<Relationship Id="{rel_id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{idx}.xml"/>')
            workbook_xml.append(f'<sheet name="{escape_xml(sheet["name"])}" sheetId="{idx}" r:id="{rel_id}"/>')
            
        content_types.append('</Types>')
        wb_rels.append('</Relationships>')
        workbook_xml.append('</sheets></workbook>')
        
        root_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

        with zipfile.ZipFile(self.filename, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('[Content_Types].xml', ''.join(content_types))
            z.writestr('_rels/.rels', root_rels)
            z.writestr('xl/workbook.xml', ''.join(workbook_xml))
            z.writestr('xl/_rels/workbook.xml.rels', ''.join(wb_rels))
            z.writestr('xl/styles.xml', self.build_styles_xml())
            for idx, sheet in enumerate(self.sheets, start=1):
                z.writestr(f'xl/worksheets/sheet{idx}.xml', self.build_worksheet_xml(sheet))

print("ExcelBuilder module defined.")
