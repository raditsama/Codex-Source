import zipfile
import xml.etree.ElementTree as ET
import html
import os

def escape_xml(s):
    if s is None:
        return ""
    return html.escape(str(s))

def prepare_rfc():
    src_path = r'C:\Works\Decommission\Procedure\ICT_RFC00225199 Workplan - Cloud Decommission 2026 - CSSP10478501.xlsx'
    dst_path = r'C:\Works\Decommission\CSSP10434772\RFC CSSP10434772 - Draft.xlsx'
    
    # 1. Read AWS confirmed resources
    aws_path = r'C:\Works\Decommission\CSSP10434772\00915_213_LIMS MLNG_AWS - Confirmed for decommisioning.xlsx'
    az_path = r'C:\Works\Decommission\CSSP10434772\00915_213_LIMS MLNG_Azure - Confirmed for decommisioning.xlsx'
    
    def get_xlsx_data(path):
        out = {}
        with zipfile.ZipFile(path) as z:
            sst = []
            if 'xl/sharedStrings.xml' in z.namelist():
                tree = ET.fromstring(z.read('xl/sharedStrings.xml'))
                for si in tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si'):
                    t_elem = si.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
                    if t_elem is not None and t_elem.text:
                        sst.append(t_elem.text)
                    else:
                        t_parts = [r.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t').text for r in si.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}r') if r.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t') is not None and r.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t').text]
                        sst.append(''.join(t_parts))
            
            wb_tree = ET.fromstring(z.read('xl/workbook.xml'))
            sheets = wb_tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheets/{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheet')
            for s in sheets:
                sheet_name = s.attrib['name']
                r_id = s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
                rels_tree = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
                rel = [r for r in rels_tree if r.attrib['Id'] == r_id][0]
                sheet_file = 'xl/' + rel.attrib['Target']
                s_tree = ET.fromstring(z.read(sheet_file))
                rows = s_tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheetData/{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')
                sheet_rows = []
                for r in rows:
                    row_vals = []
                    for c in r.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
                        v = c.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')
                        val = v.text if v is not None else ''
                        t = c.attrib.get('t')
                        if t == 's' and val and int(val) < len(sst):
                            val = sst[int(val)]
                        row_vals.append(val)
                    sheet_rows.append(row_vals)
                out[sheet_name] = sheet_rows
        return out

    aws_data = get_xlsx_data(aws_path)
    az_data = get_xlsx_data(az_path)
    
    # Collect all resources for Additional Info tab
    additional_info_rows = []
    
    # Common ticket metadata
    requester = "izdihar.roslan@petronas.com"
    custodian = "sazali.mokhtar@petronas.com"
    sr_number = "REQ000008246580"
    rfc_number = "Draft"
    cssp_number = "CSSP10434772"
    project_code = "00915_213"
    app_name = "Lab Information Management System - LIMS MLNG"
    cost_centre = "00915_213"
    
    # 1. Azure resources (Disks & RG)
    az_disks = [
        ('PTSG-5LMLNGAP01_OsDisk', 'Microsoft.Compute/disks', 'Non-prod', 'PTAZSG-IAC-DEV-LMLNG-RG', '2be5068f-e0ac-4d57-aedc-96bc9798a265', 'Azure', 'SG', '/subscriptions/2be5068f-e0ac-4d57-aedc-96bc9798a265/resourcegroups/ptazsg-iac-dev-lmlng-rg/providers/microsoft.compute/disks/ptsg-5lmlngap01_osdisk'),
        ('PTSG-5LMLNGAP01_DataDisk01', 'Microsoft.Compute/disks', 'Non-prod', 'PTAZSG-IAC-DEV-LMLNG-RG', '2be5068f-e0ac-4d57-aedc-96bc9798a265', 'Azure', 'SG', '/subscriptions/2be5068f-e0ac-4d57-aedc-96bc9798a265/resourcegroups/ptazsg-iac-dev-lmlng-rg/providers/microsoft.compute/disks/ptsg-5lmlngap01_datadisk01'),
        ('PTSG-5LMLNGAP01_DataDisk02', 'Microsoft.Compute/disks', 'Non-prod', 'PTAZSG-IAC-DEV-LMLNG-RG', '2be5068f-e0ac-4d57-aedc-96bc9798a265', 'Azure', 'SG', '/subscriptions/2be5068f-e0ac-4d57-aedc-96bc9798a265/resourcegroups/ptazsg-iac-dev-lmlng-rg/providers/microsoft.compute/disks/ptsg-5lmlngap01_datadisk02')
    ]
    for d in az_disks:
        additional_info_rows.append({
            'hostname': d[0], 'ip': '', 'type': d[1], 'env': d[2], 'rg': d[3], 'sub': d[4], 'csp': d[5], 'region': d[6],
            'proj': project_code, 'app': app_name, 'cc': cost_centre, 'resid': d[7], 'req': requester, 'cust': custodian,
            'sr': sr_number, 'rfc': rfc_number, 'cssp': cssp_number
        })
        
    # 2. AWS primary compute & core resources
    aws_core = [
        ('PTAWSG-1LMLNGAP01', '', 'AmazonEC2', 'Production', '-', '947558275301', 'AWS', 'SG', 'i-067cf8323e48354d5'),
        ('PTAWSG-1LMLNGAP02', '', 'AmazonEC2', 'Production', '-', '947558275301', 'AWS', 'SG', 'i-0ba2bdee7cf707f0e'),
        ('PTAWSG-1LMLNGAP01', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-01d581ae1adbc3be2'),
        ('PTAWSG-1LMLNGAP01', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0408ac6322453fb7f'),
        ('PTAWSG-1LMLNGAP01', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0502dc3c6869cb3e2'),
        ('PTAWSG-1LMLNGAP01-data', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0375e24688993e624'),
        ('PTAWSG-1LMLNGAP02', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0800ae5e719836e69'),
        ('PTAWSG-1LMLNGAP02', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-05eb3bc4818b9cfe1'),
        ('PTAWSG-1LMLNGAP02', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0923dd3ae47290a47'),
        ('PTAWSG-1LMLNGAP02-data', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0d40aa96604b75c3c'),
        ('PTAWSG-1LMLNGAP02-1B', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0312983d5a62496fd'),
        ('PTAWSG-1LMLNGAP02-1B', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0c5bf66f42768fbdc'),
        ('PTAWSG-1LMLNGAP02-1B', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0a7da946a800a689a'),
        ('PTAWSG-1LMLNGAP02-1B', '', 'AmazonEBS', 'Production', '-', '947558275301', 'AWS', 'SG', 'vol-0c0c996c2516f2e42'),
        ('ptawsg-1lmlngdb01', '', 'AmazonRDS', 'Production', '-', '947558275301', 'AWS', 'SG', 'arn:aws:rds:ap-southeast-1:947558275301:db:ptawsg-1lmlngdb01'),
        ('ptawsg-5lmlngdb01', '', 'AmazonRDS', 'Non-prod', '-', '407331559142', 'AWS', 'SG', 'arn:aws:rds:ap-southeast-1:407331559142:db:ptawsg-5lmlngdb01'),
        ('PTAWSG-1MLNG-APP-ALB', '', 'ElasticLoadBalancing', 'Production', '-', '947558275301', 'AWS', 'SG', 'arn:aws:elasticloadbalancing:ap-southeast-1:947558275301:loadbalancer/app/PTAWSG-1MLNG-APP-ALB/649e7c4ad99a753b'),
        ('PTAWSG-1MLNG-INT-APP-ALB', '', 'ElasticLoadBalancing', 'Production', '-', '947558275301', 'AWS', 'SG', 'arn:aws:elasticloadbalancing:ap-southeast-1:947558275301:loadbalancer/app/PTAWSG-1MLNG-INT-APP-ALB/53e2f535a46b2d4f'),
        ('cwsyn-limsmlng', '', 'AmazonCloudWatch', 'Production', '-', '575186022973', 'AWS', 'SG', 'arn:aws:logs:ap-southeast-1:575186022973:log-group:/aws/lambda/cwsyn-limsmlng-5e3f746c-51e5-49ee-9858-db4d11ac45fe')
    ]
    for c in aws_core:
        additional_info_rows.append({
            'hostname': c[0], 'ip': c[1], 'type': c[2], 'env': c[3], 'rg': c[4], 'sub': c[5], 'csp': c[6], 'region': c[7],
            'proj': project_code, 'app': app_name, 'cc': cost_centre, 'resid': c[8], 'req': requester, 'cust': custodian,
            'sr': sr_number, 'rfc': rfc_number, 'cssp': cssp_number
        })

    # 3. AWS Snapshots & other resources from confirmation file
    seen_resids = set(r['resid'] for r in additional_info_rows)
    for sheet_name in ['Sheet1', 'Sheet']:
        rows = aws_data.get(sheet_name, [])
        for r in rows[1:]:
            if sheet_name == 'Sheet1' and len(r) >= 5:
                acc = r[0]
                prod = r[2]
                name = r[3]
                resid = r[4]
                proj = r[5] if len(r)>5 else project_code
            elif sheet_name == 'Sheet' and len(r) >= 7:
                acc = r[2]
                prod = r[5]
                name = r[7]
                resid = r[6]
                proj = r[8] if len(r)>8 else project_code
            else:
                continue
                
            if resid and resid not in seen_resids:
                seen_resids.add(resid)
                env = 'Non-prod' if acc in ['407331559142', '009612143196'] else 'Production'
                additional_info_rows.append({
                    'hostname': name or 'AWS Resource', 'ip': '', 'type': prod or 'AmazonEC2', 'env': env, 'rg': '-', 'sub': acc, 'csp': 'AWS', 'region': 'SG',
                    'proj': proj or project_code, 'app': app_name, 'cc': cost_centre, 'resid': resid, 'req': requester, 'cust': custodian,
                    'sr': sr_number, 'rfc': rfc_number, 'cssp': cssp_number
                })

    print(f'Total rows to populate into Additional Info: {len(additional_info_rows)}')

    # Now let's open the template zip and update sheet1, sheet3, sheet5
    with zipfile.ZipFile(src_path, 'r') as zin:
        file_contents = {}
        for item in zin.infolist():
            file_contents[item.filename] = zin.read(item.filename)

    # 1. Update Version sheet (sheet1.xml)
    s1_tree = ET.fromstring(file_contents['xl/worksheets/sheet1.xml'])
    s1_data = s1_tree.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheetData')
    new_v_row = ET.Element('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row', {'r': '8'})
    v_cells = [
        ('A8', '1.5'),
        ('B8', 'Amendment - Updated workplan, impacted CI and additional info for CSSP10434772 (Lab Information Management System - LIMS MLNG)'),
        ('C8', '46253'), # August 2026 date
        ('D8', 'Raditya Nugraha'),
        ('E8', 'Alhusna Ab Ghani')
    ]
    for r_ref, val in v_cells:
        c_elem = ET.SubElement(new_v_row, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c', {'r': r_ref, 't': 'inlineStr'})
        is_elem = ET.SubElement(c_elem, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is')
        t_elem = ET.SubElement(is_elem, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
        t_elem.text = val
    s1_data.append(new_v_row)
    file_contents['xl/worksheets/sheet1.xml'] = ET.tostring(s1_tree, encoding='utf-8', xml_declaration=True)

    # 2. Update Workplan sheet (sheet3.xml)
    s3_tree = ET.fromstring(file_contents['xl/worksheets/sheet3.xml'])
    
    reason_for_change = (
        "Request to decommission Azure and AWS cloud virtual server and other resources (August 2026)\n"
        "For Decommission Request SR: \n\n"
        "CSSP10434772 / REQ000008246580 (Partial - Singapore Region)\n"
        "00915_213 - OCI MIGRATION - LIMS MLNG\n"
        "A-000423 - Lab Information Management System - LIMS MLNG\n"
        "(00915_213)"
    )
    business_benefit = "To reduce unused servers and cost optimization following completed migration to Malaysia (MY) region"
    
    updates = {
        'D6': reason_for_change,
        'D10': business_benefit,
        'B41': "Request to unjoin domain, shutdown server and remove from SCCM monitoring\n** List of VM as per list in Additional info tab",
        'B42': "Remove from monitoring tool (Solarwinds, E2E, Dynatrace, CloudWatch)",
        'B43': "To delete virtual machine or resources from cloud portal AWS/Azure\n** List of VM as per list in Additional info tab",
        'B44': "To verify deletion VM/resources status",
        'B45': "To remove server and update CMDB status to Disposed"
    }
    
    for c in s3_tree.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        r_ref = c.attrib.get('r')
        if r_ref in updates:
            c.attrib['t'] = 'inlineStr'
            for child in list(c):
                c.remove(child)
            is_elem = ET.SubElement(c, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is')
            t_elem = ET.SubElement(is_elem, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
            t_elem.text = updates[r_ref]
            
    file_contents['xl/worksheets/sheet3.xml'] = ET.tostring(s3_tree, encoding='utf-8', xml_declaration=True)

    # 3. Update Additional Info sheet (sheet5.xml)
    s5_tree = ET.fromstring(file_contents['xl/worksheets/sheet5.xml'])
    s5_data = s5_tree.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheetData')
    
    # Remove all rows starting from row 5
    for r in list(s5_data):
        r_idx = int(r.attrib.get('r', '0'))
        if r_idx >= 5:
            s5_data.remove(r)
            
    # Add new rows for CSSP10434772 resources
    col_keys = [
        ('A', 'hostname', '131'),
        ('B', 'ip', '131'),
        ('C', 'type', '131'),
        ('D', 'env', '131'),
        ('E', 'rg', '131'),
        ('F', 'sub', '131'),
        ('G', 'csp', '132'),
        ('H', 'region', '132'),
        ('I', 'proj', '135'),
        ('J', 'app', '117'),
        ('K', 'cc', '286'),
        ('L', 'resid', '131'),
        ('M', 'req', '134'),
        ('N', 'cust', '134'),
        ('O', 'sr', '130'),
        ('P', 'rfc', '78'),
        ('Q', 'cssp', '130')
    ]
    
    for row_num, item in enumerate(additional_info_rows, start=5):
        row_elem = ET.SubElement(s5_data, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row', {'r': str(row_num)})
        for col_letter, key, style_id in col_keys:
            val = item.get(key, '')
            c_ref = f"{col_letter}{row_num}"
            c_elem = ET.SubElement(row_elem, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c', {
                'r': c_ref,
                's': style_id,
                't': 'inlineStr'
            })
            is_elem = ET.SubElement(c_elem, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is')
            t_elem = ET.SubElement(is_elem, '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')
            t_elem.text = str(val) if val else ''

    # Update dimension
    dim = s5_tree.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}dimension')
    if dim is not None:
        dim.attrib['ref'] = f"A1:Q{len(additional_info_rows) + 5}"

    file_contents['xl/worksheets/sheet5.xml'] = ET.tostring(s5_tree, encoding='utf-8', xml_declaration=True)

    # Write out the updated zip archive
    with zipfile.ZipFile(dst_path, 'w', zipfile.ZIP_DEFLATED) as zout:
        for fname, content in file_contents.items():
            zout.writestr(fname, content)
            
    print(f"Successfully generated: {dst_path}")

if __name__ == '__main__':
    prepare_rfc()
