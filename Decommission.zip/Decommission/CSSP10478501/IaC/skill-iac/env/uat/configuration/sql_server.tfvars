/*mssql_elastic_pools = {
  ptazsg-4skilldbelasticpool = {
    resource_group_key = "PTAZSG-IAC-UAT-SKILL-RG"
    mssql_server_key   = "ptazsg-4skilldbserver"
    name               = "ptazsg-4skilldbelasticpool"
    max_size_gb        = 2

    sku = {
      name     = "GP_Gen5"
      tier     = "GeneralPurpose"
      family   = "Gen5"
      capacity = 14
    }

    per_database_settings = {
      min_capacity = 1
      max_capacity = 14
    }
  }
} */

mssql_servers = {
  ptazsg-4skilldbserver = {
    name                          = "ptazsg-4skilldbserver"
    region                        = "region1"
    resource_group_key            = "PTAZSG-IAC-UAT-SKILL-RG"
    version                       = "12.0"
    administrator_login           = "sqladmin"
    keyvault_key                  = "ptazsg-4skill-kv01"
    connection_policy             = "Default"
    public_network_access_enabled = true
    minimum_tls_version           = "1.2"

    identity = {
      type = "SystemAssigned"
      identity_ids = []
    }

    azuread_administrator = {
    azuread_authentication_only = "false"
      login_username = "PTAZ-IS-CCOE-DATABASE-CONTRIBUTOR" # COC DB TEAM
      object_id  = "87d61e09-0ae9-4ac1-9977-455277b4283b"
      tenant_id = "3b2e8941-7948-4131-978a-b2dfc7295091"
    }

    # firewall_rules = {
    #   firewall_rule1 = {
    #     name             = "firewallrule1"
    #     start_ip_address = "0.0.0.0"
    #     end_ip_address   = "0.0.0.0"
    #     # putting it to 0.0.0.0 enables the feature: Allow access to Azure services
    #   }
    #   firewall_rule2 = {
    #     name             = "ClientIPAddress"
    #     start_ip_address = "202.186.57.162"
    #     end_ip_address   = "202.186.57.162"
    #   }
    # }

    # private_endpoints = {
    #   # Require enforce_private_link_endpoint_network_policies set to true on the subnet
    #   private-link-level3 = {
    #     name               = "PTAZSG-1IAC-SKILL-SQL-PEP"
    #     lz_key             = "networking_spoke_ase"
    #     vnet_key           = "ase_region1"
    #     subnet_key         = "private_endpoints"
    #     resource_group_key = "PTAZSG-IAC-PROD-SKILL-RG"

    #     private_service_connection = {
    #       name                 = "PTAZSG-1IAC-SKILL-SQL-PEP"
    #       is_manual_connection = false
    #       subresource_names    = ["sqlServer"]
    #     }
    #     private_dns = {
    #       zone_group_name = "default"
    #       lz_key          = "private_dns"
    #       keys            = ["privatelink.database.windows.net"]
    #     }
    #   }
    # }
  }
}
