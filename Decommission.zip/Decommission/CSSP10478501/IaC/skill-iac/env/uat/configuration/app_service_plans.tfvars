app_service_plans = {
  ptazsg-4skillasp01 = {

    app_service_environment = {
      lz_key                    = "ase1"
      key                       = "ase1"
    }

    resource_group_key = "PTAZSG-IAC-UAT-SKILL-RG"

    name     = "ptazsg-4skillasp01"
    kind     = "Windows"
    is_xenon = "false"

    sku = {
      tier      = "IsolatedV2"
      size      = "I1v2"
      capacity  = "1"
    }
  }

}
