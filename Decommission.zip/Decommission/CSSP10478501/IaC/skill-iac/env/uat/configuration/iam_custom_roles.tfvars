# Custom role for app service deployment
custom_role_definitions = {
  caf_app_services_deployment_uat_skill = {
    name        = "caf_app_services_deployment_uat_skill"
    useprefix   = true
    description = "Grant access to retrieve the deployment credentials for an app service"
    permissions = {
      actions = [
        "Microsoft.Web/sites/read",
        "Microsoft.Web/sites/config/*",
        "Microsoft.Web/sites/publishxml/*",
        "Microsoft.Web/sites/config/list/action",
        "Microsoft.Web/sites/slots/*",
        "Microsoft.Web/sites/basicPublishingCredentialsPolicies/*",
        "Microsoft.Web/sites/sourcecontrols/*",
        "Microsoft.Web/serverfarms/read/*"
      ]
    }
  }
}