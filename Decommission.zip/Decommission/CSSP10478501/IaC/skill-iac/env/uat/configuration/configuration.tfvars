landingzone = {
  backend_type        = "azurerm"
  global_settings_key = "shared_services"
  level               = "level3"
  key                 = "skill"
  tfstates = {
    shared_services = {
      level   = "lower"
      tfstate = "caf_shared_services.tfstate"
    }
     ase1 = {
      level   = "current"
      tfstate = "ase1.tfstate"
    }
    networking_spoke_pep = {
      level   = "lower"
      tfstate = "networking_spoke_pep.tfstate"
    } 
  }
}

resource_groups = {
  PTAZSG-IAC-UAT-SKILL-RG = {
    name   = "PTAZSG-IAC-UAT-SKILL-RG"
    region = "region1"
  }
}

tags = {
    Project_Code          = "00617"
    ApplicationId         = "SKILL"
    ApplicationName       = "Enhancement of Sharing Knowledge Information and Lessons Learnt SKILL System for PDandT"
    environment           = "UATStaging"
    CostCenter            = "00136E003"
    DataClassification    = "Internal"
    SCAClassification     = "Critical"
    IACRepo               = "https://dev.azure.com/petronasvsts/SKILL/_git/skill-iac?path=%2F&version=GBfeature%2Fiac&_a=contents"
    ProductOwner          = "mazahari.ahmad@petronas.com"
    ProductSupport        = "mfakhrul.islam@petronas.com"
    BusinessOwner         = "zohair@petronas.com"
    CSBIA_Availability    = "Major"
    CSBIA_Confidentiality = "Major"
    CSBIA_ImpactScore     = "Major"
    CSBIA_Integrity       = "Major"
    BusinessOPU_HCU       = "Group Technical Data"
    BusinessStream        = "Project Delivery and Technology"
    SRNumber              = "REQ000006882758"
}