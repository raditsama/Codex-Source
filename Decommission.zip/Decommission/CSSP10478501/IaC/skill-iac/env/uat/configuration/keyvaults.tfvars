
keyvaults = {
  ptazsg-4skill-kv01 = {
    name                  = "ptazsg-4skill-kv01"
    resource_group_key    = "PTAZSG-IAC-UAT-SKILL-RG"
    sku_name              = "standard"
    enable_rbac_authorization = true

    creation_policies = {
      keyvault_level3_rw = {
        lz_key             = "launchpad"
        azuread_group_key  = "keyvault_level3_rw"
        secret_permissions = ["Set", "Get", "List", "Delete", "Purge"]
      }
      msi_level3 = {
        lz_key               = "launchpad"
        managed_identity_key = "level3"
        secret_permissions   = ["Set", "Get", "List", "Delete", "Purge"]
      }
    }
    soft_delete_enabled      = false
    purge_protection_enabled = false
  }
}

keyvault_access_policies = {
  ptazsg-4skill-kv01 = {
    PTAZ-DE-IS-COC-Operation-Contributor = {
      object_id          = "81bcfcfe-3ce2-416e-9ce5-e8be78723203"
      secret_permissions = ["Set", "Get", "List", "Delete", "Purge"]
    }
    skill_admin_kv_access = {
      object_id          = "84c93dbf-6c15-4b8f-bff3-214d90d0d65f"
      secret_permissions = ["Set", "Get", "List"]
    }
    skill_msi_kv_access = {
      object_id          = "dc21f250-dbce-4440-a0d7-2fb4a3707dd2"
      secret_permissions = ["Set", "Get", "List"]
    }
  }
}