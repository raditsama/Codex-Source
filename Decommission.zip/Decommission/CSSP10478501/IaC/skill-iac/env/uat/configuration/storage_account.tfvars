# App Service Backup Storage Account

storage_accounts = {

  ptazsg4skillstruat = {
    name               = "ptazsg4skillstruat"
    resource_group_key = "PTAZSG-IAC-UAT-SKILL-RG"
    # Account types are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. Defaults to StorageV2
    account_kind = "StorageV2"
    # Account Tier options are Standard and Premium. For BlockBlobStorage and FileStorage accounts only Premium is valid.
    account_tier = "Standard"
    #  Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS
    account_replication_type = "LRS" # https://docs.microsoft.com/en-us/azure/storage/common/storage-redundancy

    allow_blob_public_access = false
    public_network_access_enabled = false
    allow_nested_items_to_be_public    = false    

    # containers = {
    #   # UAT WB01
    #   backup-ptsg-4skillwb01 = {
    #     name = "backup-ptsg-4skillwb01"
    #   }
    #   # UAT API01
    #   backup-ptsg-4skillapi01 = {
    #     name = "backup-ptsg-4skillapi01"
    #   }
    # }

    private_endpoints = { 
      ptazsg4skillstruat-pep = {
        name               = "ptazsg4skillstruat-pep"
        lz_key             = "networking_spoke_pep"
        vnet_key           = "pep_region1"
        subnet_key         = "PTAZSG-4IAC-SUBNET-PEP01"
        resource_group_key = "PTAZSG-IAC-UAT-SKILL-RG"

        private_service_connection = {
          name                 = "ptazsg4skillstruat-pep"
          is_manual_connection = false
          subresource_names    = ["blob"]
        }

        private_dns = {
          zone_group_name = "default"
          lz_key          = "private_dns"
          ids             = ["/subscriptions/8a71ac81-04ed-4e9b-adea-c852951f4d69/resourceGroups/ptazsg-core-vnet-rg/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"]
        } 
      }
    }
 
  }
}