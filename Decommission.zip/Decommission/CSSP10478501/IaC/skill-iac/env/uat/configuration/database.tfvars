mssql_databases = {
  ptazsg4skillsqldb = {
    name                        = "ptazsg4skillsqldb"
    /* elastic_pool_key            = "ptazsg-4skilldbelasticpool" */
    mssql_server_key            = "ptazsg-4skilldbserver"
    resource_group_key          = "PTAZSG-IAC-UAT-SKILL-RG"
    storage_account_type        = "Local"
    sku_name                    = "Basic"
    max_size_gb                 = 2
    geo_backup_enabled          = true

    short_term_retention_policy = {
      retention_days = 7
    }
    long_term_retention_policy = {
      weekly_retention = "P5W"
      week_of_year     = "1"
    }
  }

}