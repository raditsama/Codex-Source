app_services = {
    ptazsg-4skillwb01 = {
        resource_group_key      = "PTAZSG-IAC-UAT-SKILL-RG"
        name                    = "ptazsg-4skillwb01"
        app_service_plan_key    = "ptazsg-4skillasp01"
        #application_insight_key = "ptazsg-4skillappins"

        identity = {
            type         = "SystemAssigned"
            identity_ids = null
        }

        settings = {
            enabled     = true
            https_only  = true

            site_config = {
                always_on          = true
                min_tls_version    = "1.2"
                default_documents  = ["Default.htm", "Default.html", "Default.asp", "index.htm", "index.html", "iistart.htm", "default.aspx", "index.php", "hostingstart.html"]
                websockets_enabled = true
            }
        }
        app_settings = {
            "WEBSITE_TIME_ZONE"                          = "Singapore Standard Time"
            "WEBSITE_ENABLE_SYNC_UPDATE_SITE"            = "true"
            "WEBSITE_VNET_ROUTE_ALL"          = "1"
        }
    } 
    ptazsg-4skillapi01 = {
        resource_group_key      = "PTAZSG-IAC-UAT-SKILL-RG"
        name                    = "ptazsg-4skillapi01"
        app_service_plan_key    = "ptazsg-4skillasp01"
        #application_insight_key = "ptazsg-4skillappins"

        identity = {
            type         = "SystemAssigned"
            identity_ids = null
        }

        settings = {
            enabled     = true
            https_only  = true

            site_config = {
                always_on          = true
                min_tls_version    = "1.2"
                default_documents  = ["Default.htm", "Default.html", "Default.asp", "index.htm", "index.html", "iistart.htm", "default.aspx", "index.php", "hostingstart.html"]
                websockets_enabled = true
            }
        }
         app_settings = {
            "WEBSITE_TIME_ZONE"                          = "Singapore Standard Time"
            "WEBSITE_ENABLE_SYNC_UPDATE_SITE"            = "true"
            "WEBSITE_VNET_ROUTE_ALL"          = "1"
        }
    } 
 }