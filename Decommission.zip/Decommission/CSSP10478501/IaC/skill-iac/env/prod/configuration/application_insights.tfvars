azurerm_application_insights = {
  ptazsg-1skill-appins = {
    resource_group_key = "PTAZSG-IAC-PROD-SKILL-RG"
    name               = "ptazsg-1skill-appins"
    application_type   = "web"
    log_analytics_workspace = {
      # lz_key = ""
      key = "ptazsg-1skill-log"
    }
  }
}