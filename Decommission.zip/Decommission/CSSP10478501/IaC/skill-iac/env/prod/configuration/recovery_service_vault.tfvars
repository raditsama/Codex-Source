recovery_vaults = {
  PTAZSG-IAC-PROD-SKILL-RSV = {
    name                = "PTAZSG-IAC-PROD-SKILL-RSV"
    resource_group_key  = "PTAZSG-IAC-PROD-SKILL-RG"
    region              = "region1"
    storage_mode_type = "LocallyRedundant"
    
    
    backup_policies = {
      vms = {
        PTAZSG-IAC-PROD-SKILL-RSV-VMPolicy = {
          name      = "PTAZSG-IAC-PROD-SKILL-RSV-VMPolicy"
          vault_key = "PTAZSG-IAC-PROD-SKILL-RSV "
          rg_key    = "PTAZSG-IAC-PROD-SKILL-RG"
          timezone  = "Singapore Standard Time" #default = UTC
          instant_restore_retention_days = 1
          policy_type = "V2"

          backup = {
            frequency = "Daily"
            time      = "18:00"
            #if not desired daily, can pick weekdays as below:
            #weekdays  = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
          }
          retention_daily = {
            count = 14
          }
          retention_weekly = {
            count    = 4
            weekdays = ["Friday"]
          }
          retention_monthly = {
            count    = 3
            weekdays = ["Friday"]
            weeks    = ["Last"]
          }
        }
      }
    }
  }
}
