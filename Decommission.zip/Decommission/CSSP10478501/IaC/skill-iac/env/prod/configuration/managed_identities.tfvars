managed_identities = {
  ptazsg-1skill-msi = {
    name               = "ptazsg-1skill-msi"
    resource_group_key = "PTAZSG-IAC-PROD-SKILL-RG" 
  }
}
