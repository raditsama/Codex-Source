log_analytics = {
  ptazsg-1skill-log = {
    name               = "ptazsg-1skill-log"
    resource_group_key = "PTAZSG-IAC-PROD-SKILL-RG"
  }
}