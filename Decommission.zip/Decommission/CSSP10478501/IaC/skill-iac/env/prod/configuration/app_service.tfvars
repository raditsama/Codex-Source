#
# App Services
#

app_services = {

  ptazsg-1skillwb01 = {
    resource_group_key      = "PTAZSG-IAC-PROD-SKILL-RG"
    name                    = "ptazsg-1skillwb01"
    app_service_plan_key    = "ptazsg-1skillasp01"
    application_insight_key = "ptazsg-1skill-appins"
    

    identity = {
      type         = "SystemAssigned"
      identity_ids = null
    }

    settings = {
      enabled = true
      https_only = true
      
      site_config = {
        always_on = true
        min_tls_version = "1.2"
        default_documents  = ["Default.htm", "Default.html", "Default.asp", "index.htm", "index.html", "iistart.htm", "default.aspx", "index.php", "hostingstart.html"]
        websockets_enabled = true
      }

      // backup = {
      //   name                = "backup-ptsg-1skillwb01"
      //   enabled             = true
      //   storage_account_key = "ptazsg1skillstrprod"
      //   container_key       = "backup-ptsg-1skillwb01"

      //   sas_policy = {
      //     expire_in_days = 30
      //     rotation = {
      //       #
      //       # Set how often the sas token must be rotated. When passed the renewal time, running the terraform plan / apply will change to a new sas token
      //       # Only set one of the value
      //       #

      //       # mins = 1 # only recommended for CI and demo
      //       days = 7
      //       # months = 1
      //     }
      //   }

      //   schedule = {
      //     frequency_interval       = 1
      //     frequency_unit           = "Day"
      //     keep_at_least_one_backup = true
      //     retention_period_in_days = 30
      //     # start_time                = ""
      //   }
      // }
    }

    app_settings = {
      "WEBSITE_TIME_ZONE"                          = "Singapore Standard Time"
      "WEBSITE_ENABLE_SYNC_UPDATE_SITE"            = "true"
    }
  }
  ptazsg-1skillapi01 = {
    resource_group_key      = "PTAZSG-IAC-PROD-SKILL-RG"
    name                    = "ptazsg-1skillapi01"
    app_service_plan_key    = "ptazsg-1skillasp01"
    application_insight_key = "ptazsg-1skill-appins"
    

    identity = {
      type         = "SystemAssigned"
      identity_ids = null
    }

    settings = {
      enabled = true
      https_only = true
      
      site_config = {
        always_on = true
        min_tls_version = "1.2"
        default_documents  = ["Default.htm", "Default.html", "Default.asp", "index.htm", "index.html", "iistart.htm", "default.aspx", "index.php", "hostingstart.html"]
        websockets_enabled = true
      }

      // backup = {
      //   name                = "backup-ptsg-1skillapi01"
      //   enabled             = true
      //   storage_account_key = "ptazsg1skillstrprod"
      //   container_key       = "backup-ptsg-1skillapi01"

      //   sas_policy = {
      //     expire_in_days = 30
      //     rotation = {
      //       #
      //       # Set how often the sas token must be rotated. When passed the renewal time, running the terraform plan / apply will change to a new sas token
      //       # Only set one of the value
      //       #

      //       # mins = 1 # only recommended for CI and demo
      //       days = 7
      //       # months = 1
      //     }
      //   }

      //   schedule = {
      //     frequency_interval       = 1
      //     frequency_unit           = "Day"
      //     keep_at_least_one_backup = true
      //     retention_period_in_days = 30
      //     # start_time                = ""
      //   }
      // }
    }

    app_settings = {
      "WEBSITE_TIME_ZONE"                          = "Singapore Standard Time"
      "WEBSITE_ENABLE_SYNC_UPDATE_SITE"            = "true"
    }
  }
}
