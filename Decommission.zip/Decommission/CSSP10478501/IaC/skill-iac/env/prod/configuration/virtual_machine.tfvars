# Virtual machines
// virtual_machines = {
//   # SKILL PROD App server
//   PTSG-1SKLLap01 = {
//     virtual_machine_settings = {
//       windows = {
//         name                            = "PTSG-1SKLLap01"
//         size                            = "Standard_D16s_v3"
//         admin_username                  = "manager"
//         disable_password_authentication = true
//         zone                            = "1"
//         license_type                    = "Windows_Server"
//         custom_image_id                 = "/subscriptions/8a71ac81-04ed-4e9b-adea-c852951f4d69/resourceGroups/PTAZSG-CORE-VM-IMAGES-RG/providers/Microsoft.Compute/galleries/PTAZSG_3COC_VM_Images/images/PTAZSG-3COC-WS2022-V2"

//         #To enable TrustedLaunch. Note this will increase backup cost up to 40%
//         #secure_boot_enabled             = true

//         identity = {
//           type = "UserAssigned"
//           managed_identity_ids =  ["/subscriptions/8a71ac81-04ed-4e9b-adea-c852951f4d69/resourceGroups/PTAZSG-CORE-OMS-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/ptazsg-coreoms-msi"]
//         }

//         # Value of the nic keys to attach the VM. The first one in the list is the default nic
//         network_interface_keys = ["ptsg-1skllap01-nic01"]

//         os_disk = {
//           name                 = "ptsg-1skllap01_OsDisk"
//           caching              = "ReadWrite"
//           storage_account_type = "Premium_LRS"
//           disk_size_gb         = "128"
//           zones                = [1]

//           # disk encryption setting using Customer Managed Key (CMK)
//           lz_key                  = "cmk"
//           disk_encryption_set_key = "PTAZSG-IAC-PROD-EncryptionSet"
//         }
//       }
//     }

//     backup = {
//       vault_key  = "PTAZSG-IAC-PROD-SKILL-RSV"
//       policy_key = "PTAZSG-IAC-PROD-SKILL-RSV-VMPolicy"
//       #lz_key = "" if in landing zone context, you can get the state from a remote LZ using this key
//     }

//     # Define the number of networking cards to attach the virtual machine
//     networking_interfaces = {
//       ptsg-1skllap01-nic01 = {
//         # Value of the keys from networking.tfvars
//         lz_key                  = "networking_spoke_virtual_machines"
//         vnet_key                = "vm_region1"
//         subnet_key              = "PTAZSG-1IAC-SUBNET-APP"
//         name                    = "ptsg-1skllap01-nic01"
//         enable_ip_forwarding    = false
//         internal_dns_name_label = "ptsg-1skllap01-nic01"

//         # configuration below need to be added if the nic is using dynamic IP
//         private_ip_address_allocation = "Static"
//         private_ip_address            = "172.25.192.32"
//         private_ip_address_version    = "IPv4"
//       }
//     }

//     resource_group_key                   = "PTAZSG-IAC-PROD-SKILL-RG"
//     // provision_vm_agent                   = true
//     boot_diagnostics_storage_account_key = "bootdiag_region1"
//     os_type                              = "windows"

//     # the auto-generated ssh key in keyvault secret. Secret name being {VM name}-ssh-public and {VM name}-ssh-private
//     keyvault_key = "PTAZSG-1SKILL-KV01"
//   }
// }
