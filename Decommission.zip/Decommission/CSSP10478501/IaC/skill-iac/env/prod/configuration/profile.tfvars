cdn_profile = {
  ptazsg-1skillpf = {
    name = "ptazsg-1skillpf "
    resource_group = {
      key = "PTAZSG-IAC-PROD-SKILL-RG"
    }
    # region = "region1"
    sku    = "Standard_Microsoft"
  }
}

cdn_endpoint = {
  ptazsg-1skillpep01 = {
    name   = "ptazsg-1skillpep01"
    # region = "region1"
    resource_group = {
      key = "PTAZSG-IAC-PROD-SKILL-RG"
    }
    profile = {
      key = "ptazsg-1skillpf"
    }
    origin = {
      name      = "ptazsg1skillstrprod"
      host_name = "ptazsg1skillstrprod.blob.core.windows.net"
    }
    querystring_caching_behaviour = "IgnoreQueryString"
    origin_host_header = "ptazsg1skillstrprod.blob.core.windows.net"
    # storage_account_key = "example_storage_account_key"
  }
}