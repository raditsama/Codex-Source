#
# CAF Landing zone definition
#

landingzone = {
  backend_type        = "azurerm"
  global_settings_key = "shared_services"
  level               = "level3"
  key                 = "skill"
  tfstates = {
    networking_spoke_virtual_machines = {
      level   = "lower"
      tfstate = "networking_spoke_virtual_machines.tfstate"
    }
    shared_services = {
      level   = "lower"
      tfstate = "caf_shared_services.tfstate"
    }
    # Include if using ASE 3
    ase3 = {
      level   = "current"
      tfstate = "ase3.tfstate"
    }
    cmk = {
      level   = "current"
      tfstate = "cmk.tfstate"
    }
  }
}

resource_groups = {
  PTAZSG-IAC-PROD-SKILL-RG = {
    name   = "PTAZSG-IAC-PROD-SKILL-RG"
    region = "region1" // region1 == southeastasia (refer to launchpad tfvars)
  }
}

#
# Inherited Tags
#

tags = {
  Project_Code          = "00617"
  ApplicationId         = "SKILL"
  ApplicationName       = "Enhancement of Sharing Knowledge Information & Lessons Learnt (SKILL) System for PD&T"
  environment           = "Production"
  CostCenter            = "00136E-003"
  DataClassification    = "Internal"
  SCAClassification     = "Critical"
  IACRepo               = "https://dev.azure.com/petronasvsts/SKILL/_git/skill-iac?path=%2F&version=GBfeature%2Fiac"
  ProductOwner          = "mazahari.ahmad@petronas.com"
  ProductSupport        = "mfakhrul.islam@petronas.com"
  BusinessOwner         = "zohair@petronas.com"
  CSBIA_Availability    = "Minor"
  CSBIA_Confidentiality = "Moderate"
  CSBIA_ImpactScore     = "Moderate"
  CSBIA_Integrity       = "Minor"
  BusinessOPU_HCU       = "Group Technical Data"
  BusinessStream        = "Project Delivery and Technology"
  SRNumber              = "REQ000006350102"
}
