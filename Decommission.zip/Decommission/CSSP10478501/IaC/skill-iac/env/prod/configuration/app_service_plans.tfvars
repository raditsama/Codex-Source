app_service_plans = {
  ptazsg-1skillasp01 = {
    app_service_environment = {
      lz_key                    = "ase3"
      key                       = "ase3"
    }

    resource_group_key          = "PTAZSG-IAC-PROD-SKILL-RG"
    name = "ptazsg-1skillasp01"
    kind = "Windows"
    is_xenon = "false"
    
    //When creating a Linux App Service Plan, the reserved field must be set to true
    # reserved = true

    sku = {
      tier             = "IsolatedV2"
      size             = "I3v2"
      capacity         = "1"
      per_site_scaling = true
    }
  }
}

# Auto scale out
monitor_autoscale_settings = {
  ptazsg-1skill-autoscale = {
    name               = "ptazsg-1skill-autoscale"
    enabled            = true
    resource_group_key = "PTAZSG-IAC-PROD-SKILL-RG"

    target_resource = {
      # lz_key = ""
      # vmss_key = ""
      app_service_plan_key = "ptazsg-1skillasp01"
    }

    profiles = {
      ptazsg-1skillasp01 = {
        name = "ptazsg-1skillasp01"

        capacity = {
          default = 1
          minimum = 1
          maximum = 5
        }

        rules = {
          scale_out = {
            metric_trigger = {

              # metric_name = "Percentage CPU" # vmss uses this
              # You can also choose your resource id manually, in case it is required
              # metric_resource_id = "/subscriptions/manual-id"
              metric_name      = "CpuPercentage"
              metric_namespace = "microsoft.web/serverfarms"
              time_grain       = "PT1M"
              statistic        = "Average"
              time_window      = "PT5M"
              time_aggregation = "Average"
              operator         = "GreaterThan"
              threshold        = 70
              divide_by_instance_count = true

              # dimensions = {
              #   dimension1 = {
              #     name     = "App1"
              #     operator = "Equals"
              #     values   = []
              #   }

              # }

            }
            scale_action = {
              direction = "Increase"
              type      = "ChangeCount"
              value     = "1"
              cooldown  = "PT5M"
            }
          }
        }

        recurrence = {
          timezone = "Singapore Standard Time"
          days     = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
          hours    = [8] 
          minutes  = [0]
        }
      }
    }
  }
}