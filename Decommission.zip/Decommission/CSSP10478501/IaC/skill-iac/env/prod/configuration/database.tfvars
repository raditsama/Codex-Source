// mssql_databases = {
//   ## OEXDEV DB
//   ptazsg1skilloexdevdb = {
//     name                        = "ptazsg1skilloexdevdb"
//     elastic_pool_key            = "ptazsg-1skilldbelasticpool"
//     mssql_server_key            = "ptazsg-1skilldbserver"
//     resource_group_key          = "PTAZSG-IAC-PROD-SKILL-RG"
//     storage_account_type        = "Zone"
//     sku_name                    = "ElasticPool"
//     max_size_gb                 = 500
//     geo_backup_enabled          = true

//     short_term_retention_policy = {
//       retention_days = 7
//     }
//     long_term_retention_policy = {
//       weekly_retention = "P5W"
//       week_of_year     = "1"
//     }
//   }
//   ## PDnT.SKILL DB
//   ptazsg1skillpdntdb = {
//     name                        = "ptazsg1skillpdntdb"
//     elastic_pool_key            = "ptazsg-1skilldbelasticpool"
//     mssql_server_key            = "ptazsg-1skilldbserver"
//     resource_group_key          = "PTAZSG-IAC-PROD-SKILL-RG"
//     storage_account_type        = "Zone"
//     sku_name                    = "ElasticPool"
//     max_size_gb                 = 500
//     geo_backup_enabled          = true

//     short_term_retention_policy = {
//       retention_days = 7
//     }
//     long_term_retention_policy = {
//       weekly_retention = "P5W"
//       week_of_year     = "1"
//     }
//   }
// }