# azuread_groups = {
#   skill_prod_admin = {
#     name = "skill_prod_admin"
#     description = "SKILL Administrator"
#     members = {
#       user_principal_names = [
                
#       ]
#       object_ids = [
#       ]
#       group_keys             = []
#       service_principal_keys = []
#     }
#     owners = {
#       user_principal_names = [
#       ]
#       service_principal_keys = []
#       object_ids             = []
#     }
#     prevent_duplicate_name = false
#   }
# }