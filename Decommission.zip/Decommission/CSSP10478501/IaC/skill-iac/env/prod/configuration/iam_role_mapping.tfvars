role_mapping = {
  custom_role_mapping = {
    resource_groups = {
      PTAZSG-IAC-PROD-SKILL-RG = {
        "caf_app_services_deployment_prod_skill" = {
          object_ids = {
            keys = [
              "1216d603-bbed-4fd3-8b5a-b923534f9b6c" # Provides access to L4 skill msi to retrieve publishing profiles of the app services in the resource group "PTAZSG-IAC-DEV-COC-RG"
            ]
          }
        }
      }
    }
  }

  built_in_role_mapping = {
    resource_groups = {
      PTAZSG-IAC-PROD-SKILL-RG = {
        "PTAZSG-PROD-DE-CUSTOMROLE" = {
          object_ids = {
            keys = [
              "84c93dbf-6c15-4b8f-bff3-214d90d0d65f",#SKILL = 84c93dbf-6c15-4b8f-bff3-214d90d0d65f
              "74640295-641c-4d2e-99f5-e0b59ec56593", #PRCRoom Contributor = 74640295-641c-4d2e-99f5-e0b59ec56593
              "1216d603-bbed-4fd3-8b5a-b923534f9b6c"  #L4 skill msi
            ] 
          }  
        }
      }
    }
  }
}
