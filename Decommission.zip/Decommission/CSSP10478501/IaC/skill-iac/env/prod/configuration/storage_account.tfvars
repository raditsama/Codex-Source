# App Service Backup Storage Account

// storage_accounts = {

//   ptazsg1skillstrprod = {
//     name               = "ptazsg1skillstrprod"
//     resource_group_key = "PTAZSG-IAC-PROD-SKILL-RG"
//     # Account types are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. Defaults to StorageV2
//     account_kind = "StorageV2"
//     # Account Tier options are Standard and Premium. For BlockBlobStorage and FileStorage accounts only Premium is valid.
//     account_tier = "Standard"
//     #  Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS
//     account_replication_type = "LRS" # https://docs.microsoft.com/en-us/azure/storage/common/storage-redundancy

//     containers = {
//       # PROD WB01
//       backup-ptsg-1skillwb01 = {
//         name = "backup-ptsg-1skillwb01"
//       }
//       # PROD API01
//       backup-ptsg-1skillapi01 = {
//         name = "backup-ptsg-1skillapi01"
//       }
//     }
//   }
// }