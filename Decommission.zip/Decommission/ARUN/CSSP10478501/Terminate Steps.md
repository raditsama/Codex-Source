With a **14-day data retention policy**, here is the tailored **2-Stage Decommissioning Plan**. 

This allows you to immediately terminate active billable services (Compute, App Service Plans, active VMs) while safely holding the backup data for exactly 14 days before final purging.

---

### 📅 Retention Timeline
* **Stage 1 (Immediate / Today)**: Stop active compute, terminate web apps, and set backup/data to **14-day retention mode**.
* **Stage 2 (Day 15 / After 14 Days)**: Permanently purge the retained backup vault, snapshots, and resource groups.

---

## 🔴 STAGE 1: Immediate Decommission & Retention Lock (Day 1)

Perform these actions in the **Azure Portal** today:

### 1. UAT Environment (`ptazsg-iac-uat environment`)
* [ ] **Delete App Services & Staging Slots**: `ptazsg-4skillwb01`, `ptazsg-4skillapi01` *(Ensure code/artifacts are preserved in Git/Repo if needed)*.
* [ ] **Delete App Service Plan**: `ptazsg-4skillasp01` *(Stops recurring plan billing)*.
* [ ] **Delete UAT SQL Server & Database**: `ptazsg-4skilldbserver` / `ptazsg4skillsqldb`.
* [ ] **Storage Account**: 
  - If UAT data needs 14-day retention: Go to `ptazsg4skillstruat` > **Networking** > Set to **Disabled** (leave account intact for 14 days).
  - If UAT data is discarded: **Delete** `ptazsg4skillstruat` and `sqlvaap6fputb4nxii`.
* [ ] **Delete Private Endpoint**: `ptazsg4skillstruat-pep`.

---

### 2. Production PaaS (`ptazsg-iac-prod environment`)
* [ ] **Delete App Services & Staging Slots**: `ptazsg-1skillwb01`, `ptazsg-1skillapi01`.
* [ ] **Delete App Service Plan**: `ptazsg-1skillasp01` *(Stops recurring plan billing)*.
* [ ] **Delete Log Analytics Workspace**: `ptazsg-1skill-log`.

---

### 3. Production IaaS & Core Data (`ptazsg-prod environment`)
* [ ] **Virtual Machine**:
  1. Create a Snapshot of OS disk `ptsg-1skillap01_osdisk_1_6ff17c191d364a81b988d0b640504f99` named:  
     `ptsg-1skillap01-snapshot-14d-retention` *(Standard HDD tier for lowest cost)*.
  2. **Delete** VM `ptsg-1skillap01`, NIC, and the original OS disk.
* [ ] **Recovery Services Vault (`ptazsg-prod-skill-rsv-zrs`)**:
  1. Go to Vault > **Backup items** > **Azure Virtual Machine** (`ptsg-1skillap01`).
  2. Click **Stop backup** > Choose **`Retain Backup Data`** *(DO NOT choose "Delete Backup Data")*.
  3. **DO NOT delete the Vault today** — Azure will hold the restore points for the 14-day retention period.
* [ ] **Azure SQL Database & Server (`ptsg-1skilldb01`)**:
  1. **Delete** active database `pdnt.skill`, Elastic Pool, and SQL Server `ptsg-1skilldb01`.
  2. *(Azure retains LTR / dropped database restore points automatically throughout the retention period)*.
* [ ] **Storage Account (`ptsg1skillstrg`)**:
  1. Under **Networking**, set to **Disabled** (to lock and hold for 14 days), or verify all needed files are backed up and delete.
* [ ] **Delete Private Endpoint**: `ptsg1skillstrg-blob-pep`.

---

## 🟢 STAGE 2: Post-Retention Final Purge (Day 15)

Once the 14-day retention window has passed, complete the final cleanup in the **Azure Portal**:

* [ ] **Recovery Services Vault**:
  1. Go to `ptazsg-prod-skill-rsv-zrs` > **Properties** > **Security Settings** > **Disable Soft Delete**.
  2. Go to **Backup items** > Click `...` > **Delete Backup Data** > confirm item name.
  3. Go to Vault **Overview** > Click **Delete** to remove the empty vault.
* [ ] **Delete OS Disk Snapshot**:
  - Go to **Disks / Snapshots** > Delete `ptsg-1skillap01-snapshot-14d-retention`.
* [ ] **Delete Remaining Storage Account**:
  - Delete `ptsg1skillstrg` (and `ptazsg4skillstruat` if retained).
* [ ] **Delete Empty Resource Groups**:
  - `ptazsg-prod-skill-rg`
  - `ptazsg-iac-prod-skill-rg`
  - `ptazsg-iac-uat-skill-rg`

---

### 💡 Quick Summary Checklist for Today

| Resource | Action for 14-Day Retention | What Happens to Billing/Data? |
| :--- | :--- | :--- |
| **VM `ptsg-1skillap01`** | **Take 14-day Snapshot & Delete VM** | Compute stops; snapshot holds disk data for 14 days |
| **Vault `ptazsg-prod-skill-rsv-zrs`** | **Stop Backup > "Retain Backup Data"** | No new backups run; existing restore points preserved |
| **App Services & Plans** | **Delete Immediately** | App Service Plan costs stop immediately |
| **SQL Database & Server** | **Delete Server & DB** | Compute stops; backup points remain in Azure SQL retention |
| **Storage `ptsg1skillstrg`** | **Disable Network Access** | Access locked; data held until Day 15 deletion |