
Here is the complete **resource inventory and step-by-step checklist** for stopping/suspending all services under **CSSP10478501** (Enhancement of Sharing Knowledge Information & Lessons Learnt - **SKILL System**) using the **Azure Portal**.

---

### Request Details
* **Service Request**: `CSSP10478501` / `REQ000008203411`
* **RFC Reference**: `ICT_RFC00225199`
* **Application / Project Code**: `00617` – SKILL (Sharing Knowledge Information and Lesson Learnt)
* **Subscriptions Involved**:
  1. **Prod IaaS Subscription**: `ptazsg-prod environment` (`5f782fe2-8948-4fd8-8bce-a09ad5d3cb62`)
  2. **Prod PaaS Subscription**: `ptazsg-iac-prod environment` (`e2c2906c-8901-4443-a9ee-50ffe123541a`)
  3. **UAT Subscription**: `ptazsg-iac-uat environment` (`1c334150-08b8-4088-9170-074fa26a9926`)

---

## 1. Resource Stopping Checklist

> [!IMPORTANT]
> **Order of Execution**: It is recommended to stop **Non-Production (UAT)** services first to test the procedure, followed by **Production App Services**, **Virtual Machines**, and lastly disabling network/database access.

```
CSSP10478501 Resource Shutdown Sequence
├── 1. Non-Production / UAT Environment (ptazsg-iac-uat-skill-rg)
│   ├── [ ] Stop App Service ptazsg-4skillwb01
│   ├── [ ] Stop App Service ptazsg-4skillapi01 (& staging slot)
│   ├── [ ] Restrict/Scale SQL DB ptazsg-4skilldbserver / ptazsg4skillsqldb
│   └── [ ] Restrict Storage ptazsg4skillstruat & sqlvaap6fputb4nxii
├── 2. Production PaaS Environment (ptazsg-iac-prod-skill-rg)
│   ├── [ ] Stop App Service ptazsg-1skillwb01 (& staging slot)
│   └── [ ] Stop App Service ptazsg-1skillapi01 (& staging slot)
└── 3. Production IaaS / Core Environment (ptazsg-prod-skill-rg)
    ├── [ ] Stop & Deallocate Virtual Machine ptsg-1skillap01
    ├── [ ] Stop Backup Jobs / Retain Data in Recovery Vault ptazsg-prod-skill-rsv-zrs
    ├── [ ] Restrict/Scale SQL Elastic Pool & DB ptsg-1skilldb01
    └── [ ] Restrict Storage Account ptsg1skillstrg
```

---

## 2. Step-by-Step Azure Portal Instructions

### Step 1: Virtual Machines (IaaS Compute)
**Target Resource**: `ptsg-1skillap01`  
**Subscription**: `ptazsg-prod environment` | **Resource Group**: `ptazsg-prod-skill-rg`

1. Open [Azure Portal](https://portal.azure.com).
2. Switch directory/subscription to **`ptazsg-prod environment`**.
3. Search for **Virtual machines** in the search bar and select **`ptsg-1skillap01`**.
4. On the **Overview** blade, look at the top command toolbar and click **Stop**.
5. When prompted, click **Yes** / **OK** to deallocate the VM.
6. **Verification**: Confirm the status changes to **`Stopped (deallocated)`**.  
   *(This ensures compute billing stops immediately while preserving OS disk `ptsg-1skillap01_osdisk_1_6ff17c191d364a81b988d0b640504f99`)*.

---

### Step 2: App Services & Deployment Slots (Web & API)

#### A. Production App Services
**Subscription**: `ptazsg-iac-prod environment` | **Resource Group**: `ptazsg-iac-prod-skill-rg`

* **`ptazsg-1skillwb01` (Web App + Staging Slot)**:
  1. Navigate to **App Services** -> select **`ptazsg-1skillwb01`**.
  2. On the **Overview** toolbar, click **Stop** (Click *Yes* to confirm).
  3. In the left menu under *Deployment*, click **Deployment slots**.
  4. Click on the **`staging`** slot -> click **Stop** on its Overview toolbar.
* **`ptazsg-1skillapi01` (API App + Staging Slot)**:
  1. Navigate to **App Services** -> select **`ptazsg-1skillapi01`**.
  2. On the **Overview** toolbar, click **Stop**.
  3. Under *Deployment*, click **Deployment slots** -> select **`staging`** -> click **Stop**.

#### B. UAT App Services
**Subscription**: `ptazsg-iac-uat environment` | **Resource Group**: `ptazsg-iac-uat-skill-rg`

* **`ptazsg-4skillwb01` (Web App)**:
  1. Navigate to **App Services** -> select **`ptazsg-4skillwb01`** -> click **Stop**.
* **`ptazsg-4skillapi01` (API App + Staging Slot)**:
  1. Navigate to **App Services** -> select **`ptazsg-4skillapi01`** -> click **Stop**.
  2. Under *Deployment*, click **Deployment slots** -> select **`staging`** -> click **Stop**.

> [!TIP]
> *App Service Plans (`ptazsg-1skillasp01` and `ptazsg-4skillasp01`)* incur hourly charges while provisioned even if Web Apps are stopped. Once all apps are stopped, you can optionally scale down the App Service Plan instance count to 0 or minimum if permitted before final deletion.

---

### Step 3: Recovery Services Vault (Backups)
**Target Resource**: `ptazsg-prod-skill-rsv-zrs`  
**Subscription**: `ptazsg-prod environment` | **Resource Group**: `ptazsg-prod-skill-rg`

1. Navigate to **Recovery Services vaults** -> select **`ptazsg-prod-skill-rsv-zrs`**.
2. Under *Protected items*, click **Backup items**.
3. Select the items protected under **Azure Virtual Machine** (e.g., `ptsg-1skillap01`).
4. Click the context menu (`...`) or click the item -> click **Stop backup**.
5. In the *Stop Backup* panel:
   - Select option: **Retain Backup Data** *(mandatory as per corporate retention policy, e.g. 3 months)*.
   - Enter the name to confirm and click **Stop backup**.

---

### Step 4: Azure SQL Databases & Elastic Pools
> [!NOTE]
> Azure SQL Database (DTU/Elastic Pool) does not provide a standard "Stop" button. To halt operations and prevent connections:

#### A. Production SQL Server & Elastic Pool
**Target**: `ptsg-1skilldb01` | **Subscription**: `ptazsg-prod environment`
1. Navigate to **SQL servers** -> select **`ptsg-1skilldb01`**.
2. Under *Security*, click **Networking**.
3. Set **Public network access** to **Disabled** (or remove existing firewall IP whitelist rules) to block incoming connections.
4. If scaling down is desired to save costs before final deletion:
   - Under *Settings*, go to **Elastic pools** -> select `ptsg-1skilldb01` -> scale down vCore/eDTUs to the lowest tier.

#### B. UAT SQL Server & Database
**Target**: `ptazsg-4skilldbserver` / `ptazsg4skillsqldb` | **Subscription**: `ptazsg-iac-uat environment`
1. Navigate to **SQL servers** -> select **`ptazsg-4skilldbserver`**.
2. Under *Security* -> **Networking** -> Set **Public network access** to **Disabled**.
3. Under *Settings* -> **SQL Databases** -> select `ptazsg4skillsqldb` -> **Compute + storage** -> Scale down to Basic (5 DTUs).

---

### Step 5: Storage Accounts & Private Endpoints
> [!NOTE]
> Azure Storage accounts cannot be stopped directly. To suspend service access and isolate storage:

* **Storage Accounts**:
  - `ptsg1skillstrg` (Prod)
  - `ptazsg4skillstruat` (UAT)
  - `sqlvaap6fputb4nxii` (UAT Diagnostic/VA storage)
* **Instructions for each Storage Account**:
  1. Navigate to **Storage accounts** -> Select the storage account.
  2. Under *Security + networking*, click **Networking**.
  3. Under *Firewalls and virtual networks*, select **Disabled** (or *Enabled from selected virtual networks and IP addresses* with no IPs whitelisted).
  4. Click **Save**.

---

## 3. Summary Inventory Reference Table

| Environment | Resource Group | Resource Name | Resource Type | Action in Portal |
| :--- | :--- | :--- | :--- | :--- |
| **Prod (IaaS)** | `ptazsg-prod-skill-rg` | `ptsg-1skillap01` | Virtual Machine | **Stop (Deallocate)** |
| **Prod (IaaS)** | `ptazsg-prod-skill-rg` | `ptazsg-prod-skill-rsv-zrs` | Recovery Services Vault | **Stop Backup (Retain Data)** |
| **Prod (IaaS)** | `ptazsg-prod-skill-rg` | `ptsg-1skilldb01` | SQL Elastic Pool / Server | **Disable Network / Scale Down** |
| **Prod (IaaS)** | `ptazsg-prod-skill-rg` | `ptsg1skillstrg` | Storage Account | **Disable Public Access** |
| **Prod (IaaS)** | `ptazsg-prod-skill-rg` | `ptsg1skillstrg-blob-pep` | Private Endpoint | *(Passive)* |
| **Prod (PaaS)** | `ptazsg-iac-prod-skill-rg` | `ptazsg-1skillwb01` | App Service + Slot | **Stop App & Staging Slot** |
| **Prod (PaaS)** | `ptazsg-iac-prod-skill-rg` | `ptazsg-1skillapi01` | App Service + Slot | **Stop App & Staging Slot** |
| **Prod (PaaS)** | `ptazsg-iac-prod-skill-rg` | `ptazsg-1skillasp01` | App Service Plan | *(Scaled/Stopped with apps)* |
| **Prod (PaaS)** | `ptazsg-iac-prod-skill-rg` | `ptazsg-1skill-log` | Log Analytics Workspace | *(Passive monitoring sink)* |
| **UAT** | `ptazsg-iac-uat-skill-rg` | `ptazsg-4skillwb01` | App Service | **Stop App** |
| **UAT** | `ptazsg-iac-uat-skill-rg` | `ptazsg-4skillapi01` | App Service + Slot | **Stop App & Staging Slot** |
| **UAT** | `ptazsg-iac-uat-skill-rg` | `ptazsg-4skillasp01` | App Service Plan | *(Scaled/Stopped with apps)* |
| **UAT** | `ptazsg-iac-uat-skill-rg` | `ptazsg-4skilldbserver` | SQL Database / Server | **Disable Network / Scale Down** |
| **UAT** | `ptazsg-iac-uat-skill-rg` | `ptazsg4skillstruat` | Storage Account | **Disable Public Access** |
| **UAT** | `ptazsg-iac-uat-skill-rg` | `sqlvaap6fputb4nxii` | Storage Account | **Disable Public Access** |
| **UAT** | `ptazsg-iac-uat-skill-rg` | `ptazsg4skillstruat-pep` | Private Endpoint | *(Passive)* |

---

Please let me know once you have performed or validated these steps, or if you want to proceed with the IaC / pipeline decommissioning review next!