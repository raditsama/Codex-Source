# CSSP Current Provisioning and Decommissioning Flows

**Sole reference:** `E:\Laporan-Petronas\Work Reference\CSSP Flow - For Review.xlsx`

The workbook contains a 34-step provisioning process and a 23-step decommissioning process. The diagrams preserve its gates, roles, decisions, return loops, and operational notes. No other source has been used.

## Provisioning — current state

```mermaid
flowchart TD
    P1["1 · User<br/>Submit CSSP provisioning ticket<br/>Application, project, SR, retention duration,<br/>justification, resource list and HLD"]
    P2["2 · User Manager<br/>Gate-1: Resource Review"]
    PD2{"Accept request for Gate-2?"}
    PR1["Request rejected"]
    P3["3 · Solution Architect<br/>Gate-2: Request Approval"]
    PD3{"Accept request for Gate-3?"}
    P3A["Dispose ticket to a department"]
    PD3A{"Disposed to the correct CSSP<br/>provisioning and decommissioning team?"}
    PO["Ticket remains open but cannot be followed up"]

    P4["4 · CSSP Leader<br/>Gate-3: Final Review<br/>Check completeness, Azure DevOps access,<br/>IaC repository and new/existing application"]
    PD4{"Azure DevOps project<br/>exists and is accessible?"}
    P5["5 · CSSP Leader<br/>Ask user by email or Teams to share access"]
    P6["6 · User<br/>Confirm Azure DevOps access"]
    P7["7 · CSSP Leader<br/>Assign engineer for Gate-4<br/>Update SR to executing, start SLA<br/>and provide related Azure repository"]

    PD7{"Existing project IaC repository?"}
    P8["8 · Engineer<br/>Pull/fetch vending IaC repository<br/>and create a new branch"]
    P9["9 · Engineer<br/>Script the vending configuration"]
    P10["10 · Engineer<br/>Test Terraform plan, submit pull request<br/>and inform COC"]
    P11["11 · COC<br/>Verify pull request"]
    PD11{"Pull request approved?"}
    P12["12 · Engineer<br/>Actively check approval, run Terraform apply<br/>from main branch and inform COC"]
    P13["13 · COC<br/>Verify Terraform apply pipeline"]
    PD13{"Apply pipeline approved?"}
    P14["14 · Engineer<br/>Actively check approval and apply result"]
    PD14{"Terraform apply working?"}
    PV["Vending complete<br/>New IaC repository is available"]

    P15["15 · Engineer<br/>Pull/fetch project IaC repository<br/>and create a new branch"]
    P16["16 · Engineer<br/>Identify resources covered by the project repo<br/>and resources requiring another repo"]
    PD16{"Resource covered by<br/>intended project IaC repo?"}

    P17["17 · Engineer<br/>Script resources in intended project repo"]
    P18["18 · Engineer<br/>Test Terraform plan, submit pull request<br/>and inform COC"]
    P19["19 · COC<br/>Verify pull request"]
    PD19{"Pull request approved?"}
    P20["20 · Engineer<br/>Actively check approval, run Terraform apply<br/>from main branch and inform COC"]
    P21["21 · COC<br/>Verify Terraform apply pipeline"]
    PD21{"Apply pipeline approved?"}
    P22["22 · Engineer<br/>Actively check approval and apply result"]
    PD22{"Terraform apply working?"}
    PD22A{"All intended resources covered<br/>by the project IaC repo?"}

    P23["23 · Engineer<br/>Pull/fetch IaC repo for resources outside<br/>the intended project repo; create branch"]
    P24["24 · Engineer<br/>Script resources in the additional repo"]
    P25["25 · Engineer<br/>Test Terraform plan, submit pull request<br/>and inform COC"]
    P26["26 · COC<br/>Verify pull request"]
    PD26{"Pull request approved?"}
    P27["27 · Engineer<br/>Actively check approval, run Terraform apply<br/>from main branch and inform COC"]
    P28["28 · COC<br/>Verify Terraform apply pipeline"]
    PD28{"Apply pipeline approved?"}
    P29["29 · Engineer<br/>Actively check approval and apply result"]
    PD29{"Terraform apply working?"}
    PU["Apply pipeline rejected by COC<br/>Next process step is not stated in the workbook"]

    P30["30 · Engineer<br/>Perform final task check"]
    P31["31 · Engineer<br/>Inform user that resources are deployed"]
    P32["32 · User<br/>Verify the deployment"]
    P33["33 · Engineer<br/>Evaluate user verification"]
    PD33{"User happy with deployment?"}
    P34["34 · Engineer<br/>Close CSSP ticket"]

    PN1["Workbook note<br/>Azure DevOps access delay continues ticket aging"]
    PN2["Workbook note<br/>SR status may not update when assigned"]
    PN3["Workbook note<br/>CSSP Leader has no proper WIP control for assignment"]

    P1 --> P2 --> PD2
    PD2 -- No --> PR1
    PD2 -- Yes --> P3 --> PD3
    PD3 -- No --> PR1
    PD3 -- Yes --> P3A --> PD3A
    PD3A -- No --> PO
    PD3A -- Yes --> P4 --> PD4
    PD4 -- No --> P5 --> P6 --> P4
    PD4 -- Yes --> P7 --> PD7

    PD7 -- No --> P8 --> P9 --> P10 --> P11 --> PD11
    PD11 -- No --> P9
    PD11 -- Yes --> P12 --> P13 --> PD13
    PD13 -- No --> PU
    PD13 -- Yes --> P14 --> PD14
    PD14 -- No --> P9
    PD14 -- Yes --> PV --> P15
    PD7 -- Yes --> P15

    P15 --> P16 --> PD16
    PD16 -- Yes --> P17 --> P18 --> P19 --> PD19
    PD19 -- No --> P17
    PD19 -- Yes --> P20 --> P21 --> PD21
    PD21 -- No --> PU
    PD21 -- Yes --> P22 --> PD22
    PD22 -- No --> P17
    PD22 -- Yes --> PD22A
    PD22A -- Yes --> P30
    PD22A -- No --> P23

    PD16 -- No --> P23 --> P24 --> P25 --> P26 --> PD26
    PD26 -- No --> P24
    PD26 -- Yes --> P27 --> P28 --> PD28
    PD28 -- No --> PU
    PD28 -- Yes --> P29 --> PD29
    PD29 -- No --> P24
    PD29 -- Yes --> P30

    P30 --> P31 --> P32 --> P33 --> PD33
    PD33 -- No --> P16
    PD33 -- Yes --> P34

    PN1 -.-> P5
    PN2 -.-> P7
    PN3 -.-> P7

    classDef user fill:#E8F3FF,stroke:#2D6F91,color:#111820;
    classDef manager fill:#F1F2F3,stroke:#69737D,color:#111820;
    classDef leader fill:#DDF3ED,stroke:#008673,color:#111820;
    classDef engineer fill:#EAF7F3,stroke:#008673,color:#111820;
    classDef coc fill:#FFF1CC,stroke:#D99A16,color:#111820;
    classDef decision fill:#FFFFFF,stroke:#111820,color:#111820;
    classDef exception fill:#FBE4E4,stroke:#C54848,color:#111820;
    classDef note fill:#FFF8E8,stroke:#F3BE53,color:#111820;
    class P1,P6,P32 user;
    class P2,P3,P3A manager;
    class P4,P5,P7 leader;
    class P8,P9,P10,P12,P14,P15,P16,P17,P18,P20,P22,P23,P24,P25,P27,P29,P30,P31,P33,P34 engineer;
    class P11,P13,P19,P21,P26,P28 coc;
    class PD2,PD3,PD3A,PD4,PD7,PD11,PD13,PD14,PD16,PD19,PD21,PD22,PD22A,PD26,PD28,PD29,PD33 decision;
    class PR1,PO,PU exception;
    class PN1,PN2,PN3 note;
```

## Decommissioning — current state

```mermaid
flowchart TD
    D1["1 · User<br/>Submit CSSP decommissioning ticket<br/>Application, project, backup retention, SR,<br/>retention duration, justification and resource list"]
    D2["2 · User Manager<br/>Gate-1: Resource Review"]
    DD2{"Accept request for Gate-2?"}
    DR1["Request rejected"]
    D3["3 · Solution Architect<br/>Gate-2: Request Approval"]
    DD3{"Accept request for Gate-3?"}
    D3A["Dispose ticket to a department"]
    DD3A{"Disposed to the correct CSSP<br/>provisioning and decommissioning team?"}
    DO["Ticket remains open but cannot be followed up"]

    D4A["4 · CSSP Leader<br/>Gate-3: Final Review<br/>Check completeness, email resource list to user,<br/>check IaC deployment and related Azure repo"]
    DD4{"User confirms the resources<br/>to be deleted?"}
    D4B["4 · CSSP Leader<br/>Assign engineer for Gate-4<br/>Update SR to executing, start SLA,<br/>share confirmed email and Azure repo"]
    D5["5 · Engineer<br/>Accept ticket; check each resource exists,<br/>is IaC-related and is active; stop active resource<br/>after hours; update status; start backup/retention"]
    D6["6 · Engineer<br/>Prepare RFC document for deletion scope"]
    D7["7 · Engineer<br/>Submit CR in ITSM, upload RFC, arrange execution<br/>and coordinate related departments"]
    D8["8 · Engineer<br/>Determine whether resources are related to IaC"]
    DD8{"IaC-related resource?"}

    D9["9 · Engineer<br/>Run Terraform plan and align it<br/>with the confirmed resource list"]
    D10["10 · Engineer<br/>Customize IaC, validate with Terraform plan<br/>and fix drift"]
    D11["11 · Engineer<br/>Execute Terraform plan/apply pipeline"]
    D12["12 · Engineer<br/>Final-check Terraform plan against<br/>resources intended for deletion"]
    D13["13 · Engineer<br/>Inform COC that pipeline is ready for verification"]
    D14["14 · COC<br/>Verify pipeline"]
    DD14{"COC approves?"}
    D15["15 · Engineer<br/>Actively check Terraform apply result"]
    DD15{"Terraform apply working?"}
    D16["16 · Engineer<br/>Check remaining resources not covered by IaC"]
    DD16{"Any resource still requires<br/>manual deletion?"}

    D17["17 · Engineer<br/>Delete resources manually in console/portal"]
    DD17{"Deletion succeeds in console/portal?"}
    D18["18 · Engineer<br/>Coordinate with Cloud Operation team"]
    D19["19 · Engineer<br/>Update resource status"]
    D20["20 · Engineer<br/>Update CR ticket in ITSM/BMC regarding RFC"]
    D21["21 · Other Department<br/>Follow up CR ticket regarding RFC"]
    D22["22 · Engineer<br/>Close CSSP ticket"]
    D23["23 · Engineer<br/>Inform user of status by email"]

    DN1["Workbook note<br/>User may confirm a different deletion list<br/>from the CSSP ticket"]
    DN2["Workbook note<br/>User confirmation delay continues ticket aging"]
    DN3["Workbook note<br/>SR status may not update when assigned"]
    DN4["Workbook note<br/>CSSP Leader has no proper WIP control for assignment"]
    DN5["Workbook note<br/>COC does not actively inform engineer of apply result"]

    D1 --> D2 --> DD2
    DD2 -- No --> DR1
    DD2 -- Yes --> D3 --> DD3
    DD3 -- No --> DR1
    DD3 -- Yes --> D3A --> DD3A
    DD3A -- No --> DO
    DD3A -- Yes --> D4A --> DD4
    DD4 -- No --> D4A
    DD4 -- Yes --> D4B --> D5 --> D6 --> D7 --> D8 --> DD8

    DD8 -- Yes --> D9 --> D10 --> D11 --> D12 --> D13 --> D14 --> DD14
    DD14 -- No --> D9
    DD14 -- Yes --> D15 --> DD15
    DD15 -- No --> D9
    DD15 -- Yes --> D16 --> DD16
    DD16 -- Yes --> D17
    DD16 -- No --> D19

    DD8 -- No --> D17 --> DD17
    DD17 -- No --> D18 --> D19
    DD17 -- Yes --> D19
    D19 --> D20 --> D21 --> D22 --> D23

    DN1 -.-> D4A
    DN2 -.-> DD4
    DN3 -.-> D4B
    DN4 -.-> D4B
    DN5 -.-> D15

    classDef user fill:#E8F3FF,stroke:#2D6F91,color:#111820;
    classDef manager fill:#F1F2F3,stroke:#69737D,color:#111820;
    classDef leader fill:#DDF3ED,stroke:#008673,color:#111820;
    classDef engineer fill:#EAF7F3,stroke:#008673,color:#111820;
    classDef coc fill:#FFF1CC,stroke:#D99A16,color:#111820;
    classDef other fill:#EEE8FF,stroke:#7257A8,color:#111820;
    classDef decision fill:#FFFFFF,stroke:#111820,color:#111820;
    classDef exception fill:#FBE4E4,stroke:#C54848,color:#111820;
    classDef note fill:#FFF8E8,stroke:#F3BE53,color:#111820;
    class D1 user;
    class D2,D3,D3A manager;
    class D4A,D4B leader;
    class D5,D6,D7,D8,D9,D10,D11,D12,D13,D15,D16,D17,D18,D19,D20,D22,D23 engineer;
    class D14 coc;
    class D21 other;
    class DD2,DD3,DD3A,DD4,DD8,DD14,DD15,DD16,DD17 decision;
    class DR1,DO exception;
    class DN1,DN2,DN3,DN4,DN5 note;
```

## Role colour key

- **Blue:** User
- **Grey:** User Manager or Solution Architect
- **Green:** CSSP Leader or Engineer
- **Yellow:** COC
- **Purple:** Other Department
- **Red:** rejected or incorrectly disposed ticket outcome
- **Pale yellow note:** operational note stated in the workbook

For provisioning, the workbook does not state the next action when COC rejects a Terraform apply pipeline. Those branches therefore end in a red “next step not stated” node rather than adding an assumed return path.
